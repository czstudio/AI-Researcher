"""CPU-only numerical and architecture tests (no datasets or downloads needed).

Run from the project root:
    python -B -m unittest discover -s tests -p 'test_models.py' -v

PyTorch BatchNorm is used only as a numerical oracle in this test module.
"""

from pathlib import Path
import sys
import unittest

import torch
from torch import nn

# Supports unittest discovery even without a package __init__.py.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.models import (MNISTMLP, PaperBatchNorm, SmallInception,
                        paper_batch_norm_equations)


def equation_reference(x, gamma, beta, eps):
    """Independent test reference: explicitly center and square, no BN primitive."""
    axes = (0,) if x.ndim == 2 else (0, 2, 3)
    shape = (1, -1) if x.ndim == 2 else (1, -1, 1, 1)
    mean = x.mean(dim=axes, keepdim=True)
    centered = x - mean
    biased_variance = centered.square().mean(dim=axes, keepdim=True)
    output = gamma.reshape(shape) * centered / (biased_variance + eps).sqrt()
    return output + beta.reshape(shape), mean.reshape(-1), biased_variance.reshape(-1)


class CPUModelTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.previous_threads = torch.get_num_threads()
        # Tiny tensors and convolutions are much faster without thread oversubscription.
        torch.set_num_threads(1)

    @classmethod
    def tearDownClass(cls):
        torch.set_num_threads(cls.previous_threads)

    def assertClose(self, actual, expected, rtol=1e-9, atol=1e-10):
        torch.testing.assert_close(actual, expected, rtol=rtol, atol=atol)


class PaperBatchNormTests(CPUModelTestCase):
    def test_defaults_and_parameter_aliases(self):
        bn = PaperBatchNorm(3)
        self.assertEqual(bn.eps, 1e-5)
        self.assertEqual(bn.momentum, 0.1)
        self.assertIs(bn.weight, bn.gamma)
        self.assertIs(bn.bias, bn.beta)
        self.assertClose(bn.gamma, torch.ones(3))
        self.assertClose(bn.beta, torch.zeros(3))
        self.assertClose(bn.running_mean, torch.zeros(3))
        self.assertClose(bn.running_var, torch.ones(3))
        self.assertEqual(set(dict(bn.named_parameters())), {"gamma", "beta"})
        self.assertTrue(all(t.device.type == "cpu" for t in bn.state_dict().values()))

    def _compare_training(self, shape):
        generator = torch.Generator(device="cpu").manual_seed(101)
        features = shape[1]
        bn = PaperBatchNorm(features, eps=2e-5, momentum=0.23).double()
        oracle_type = nn.BatchNorm1d if len(shape) == 2 else nn.BatchNorm2d
        oracle = oracle_type(features, eps=bn.eps, momentum=bn.momentum).double()
        with torch.no_grad():
            bn.gamma.copy_(torch.randn(features, generator=generator, dtype=torch.double))
            bn.beta.copy_(torch.randn(features, generator=generator, dtype=torch.double))
            oracle.weight.copy_(bn.gamma)
            oracle.bias.copy_(bn.beta)
        expected_mean = torch.zeros(features, dtype=torch.double)
        expected_variance = torch.ones(features, dtype=torch.double)
        sample_count = shape[0] if len(shape) == 2 else shape[0] * shape[2] * shape[3]
        for step in range(3):
            # Different means/variances exercise the momentum convention over time.
            data = torch.randn(shape, generator=generator, dtype=torch.double) * (step + 1) + step
            x = data.clone().requires_grad_()
            oracle_x = data.clone().requires_grad_()
            reference_x = data.clone().requires_grad_()
            reference_gamma = bn.gamma.detach().clone().requires_grad_()
            reference_beta = bn.beta.detach().clone().requires_grad_()
            bn.zero_grad(set_to_none=True)
            oracle.zero_grad(set_to_none=True)
            output = bn(x)
            oracle_output = oracle(oracle_x)
            reference, mean, variance = equation_reference(
                reference_x, reference_gamma, reference_beta, bn.eps
            )
            self.assertClose(output, oracle_output)
            self.assertClose(output, reference)
            self.assertClose(output, paper_batch_norm_equations(x, bn.gamma, bn.beta, bn.eps))
            upstream = torch.randn(shape, generator=generator, dtype=torch.double)
            (output * upstream).sum().backward()
            (oracle_output * upstream).sum().backward()
            (reference * upstream).sum().backward()
            self.assertClose(x.grad, oracle_x.grad)
            self.assertClose(x.grad, reference_x.grad)
            self.assertClose(bn.gamma.grad, oracle.weight.grad)
            self.assertClose(bn.beta.grad, oracle.bias.grad)
            self.assertClose(bn.gamma.grad, reference_gamma.grad)
            self.assertClose(bn.beta.grad, reference_beta.grad)
            expected_mean = (1 - bn.momentum) * expected_mean + bn.momentum * mean.detach()
            expected_variance = ((1 - bn.momentum) * expected_variance
                                 + bn.momentum * variance.detach() * sample_count / (sample_count - 1))
            self.assertClose(bn.running_mean, oracle.running_mean)
            self.assertClose(bn.running_var, oracle.running_var)
            self.assertClose(bn.running_mean, expected_mean)
            self.assertClose(bn.running_var, expected_variance)
            self.assertEqual(bn.num_batches_tracked.item(), step + 1)
            self.assertEqual(bn.num_batches_tracked.item(), oracle.num_batches_tracked.item())
            self.assertFalse(bn.running_mean.requires_grad)
            self.assertFalse(bn.running_var.requires_grad)

    def test_training_2d_outputs_gradients_and_running_statistics(self):
        self._compare_training((7, 4))

    def test_training_4d_outputs_gradients_and_running_statistics(self):
        self._compare_training((3, 4, 5, 6))

    def test_equation_gradcheck_2d_and_4d(self):
        generator = torch.Generator(device="cpu").manual_seed(102)
        for shape in ((4, 2), (2, 2, 2, 2)):
            with self.subTest(shape=shape):
                x = torch.randn(shape, generator=generator, dtype=torch.double, requires_grad=True)
                gamma = torch.randn(2, generator=generator, dtype=torch.double, requires_grad=True)
                beta = torch.randn(2, generator=generator, dtype=torch.double, requires_grad=True)
                self.assertTrue(torch.autograd.gradcheck(
                    paper_batch_norm_equations, (x, gamma, beta),
                    eps=1e-6, atol=1e-5, rtol=1e-3,
                ))

    def test_eval_invariant_to_batch_composition_and_matches_oracle(self):
        generator = torch.Generator(device="cpu").manual_seed(103)
        for shape in ((5, 3), (5, 3, 4, 4)):
            with self.subTest(shape=shape):
                bn = PaperBatchNorm(3).double()
                bn(torch.randn(shape, generator=generator, dtype=torch.double))
                bn.eval()
                before = {key: value.clone() for key, value in bn.state_dict().items()}
                data = torch.randn(shape, generator=generator, dtype=torch.double)
                target = data[:1]
                companions = 100 * torch.randn(shape, generator=generator, dtype=torch.double)
                self.assertClose(bn(target), bn(torch.cat((target, companions), dim=0))[:1])
                self.assertClose(bn(target), bn(data)[:1])
                shape_broadcast = (1, 3) if len(shape) == 2 else (1, 3, 1, 1)
                expected = ((target - bn.running_mean.reshape(shape_broadcast))
                            / (bn.running_var.reshape(shape_broadcast) + bn.eps).sqrt())
                expected = expected * bn.gamma.reshape(shape_broadcast) + bn.beta.reshape(shape_broadcast)
                self.assertClose(bn(target), expected)
                oracle_type = nn.BatchNorm1d if len(shape) == 2 else nn.BatchNorm2d
                oracle = oracle_type(3, eps=bn.eps).double().eval()
                with torch.no_grad():
                    oracle.weight.copy_(bn.gamma)
                    oracle.bias.copy_(bn.beta)
                    oracle.running_mean.copy_(bn.running_mean)
                    oracle.running_var.copy_(bn.running_var)
                self.assertClose(bn(data), oracle(data))
                for key, value in bn.state_dict().items():
                    self.assertClose(value, before[key], rtol=0, atol=0)

    def test_single_image_4d_is_valid_with_spatial_samples(self):
        self._compare_training((1, 2, 3, 4))

    def test_constant_inputs_are_finite_and_beta_only(self):
        for shape in ((4, 2), (2, 2, 3, 3)):
            with self.subTest(shape=shape):
                bn = PaperBatchNorm(2).double()
                with torch.no_grad():
                    bn.beta.copy_(torch.tensor([2.0, -3.0], dtype=torch.double))
                x = torch.zeros(shape, dtype=torch.double, requires_grad=True)
                output = bn(x)
                expected = bn.beta.reshape((1, 2) if len(shape) == 2 else (1, 2, 1, 1)).expand(shape)
                self.assertClose(output, expected)
                self.assertClose(output, paper_batch_norm_equations(x, bn.gamma, bn.beta))
                output.sum().backward()
                self.assertTrue(torch.isfinite(x.grad).all().item())
                self.assertClose(bn.running_var, torch.full((2,), 0.9, dtype=torch.double))

    def test_invalid_inputs_and_arguments(self):
        for kwargs in ({"num_features": 0}, {"num_features": 2, "eps": 0},
                       {"num_features": 2, "momentum": -0.1},
                       {"num_features": 2, "momentum": 1.1}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                PaperBatchNorm(**kwargs)
        bn = PaperBatchNorm(2)
        for shape in ((2,), (2, 2, 2), (2, 3), (1, 2), (1, 2, 1, 1)):
            with self.subTest(shape=shape), self.assertRaises(ValueError):
                bn(torch.zeros(shape))
        with self.assertRaises(ValueError):
            paper_batch_norm_equations(torch.zeros(1, 2), torch.ones(2), torch.zeros(2))
        with self.assertRaises(ValueError):
            paper_batch_norm_equations(torch.zeros(3, 2), torch.ones(3), torch.zeros(2))
        bn.eval()
        self.assertEqual(tuple(bn(torch.zeros(1, 2)).shape), (1, 2))

    def test_reset_and_state_roundtrip(self):
        bn = PaperBatchNorm(3)
        bn(torch.arange(18, dtype=torch.float32).reshape(6, 3))
        restored = PaperBatchNorm(3)
        restored.load_state_dict(bn.state_dict())
        bn.eval()
        restored.eval()
        x = torch.arange(9, dtype=torch.float32).reshape(3, 3)
        self.assertClose(restored(x), bn(x), rtol=0, atol=0)
        restored.reset_parameters()
        self.assertClose(restored.gamma, torch.ones(3))
        self.assertClose(restored.beta, torch.zeros(3))
        self.assertClose(restored.running_mean, torch.zeros(3))
        self.assertClose(restored.running_var, torch.ones(3))
        self.assertEqual(restored.num_batches_tracked.item(), 0)


class ModelTests(CPUModelTestCase):
    def affine_layers(self, model):
        return [layer for layer in model.modules() if isinstance(layer, (nn.Conv2d, nn.Linear))]

    def assertMatchedWeights(self, first, second):
        first_layers = self.affine_layers(first)
        second_layers = self.affine_layers(second)
        self.assertEqual(len(first_layers), len(second_layers))
        for index, (left, right) in enumerate(zip(first_layers, second_layers)):
            with self.subTest(layer=index):
                self.assertEqual(type(left), type(right))
                self.assertClose(left.weight, right.weight, rtol=0, atol=0)
                for layer in (left, right):
                    self.assertEqual(layer.weight.device.type, "cpu")
                    if layer.bias is not None:
                        self.assertClose(layer.bias, torch.zeros_like(layer.bias), rtol=0, atol=0)

    def test_mnist_output_shapes_and_backward(self):
        for use_bn in (False, True):
            with self.subTest(use_bn=use_bn):
                model = MNISTMLP(use_bn=use_bn, seed=201)
                image = torch.randn(4, 1, 28, 28, requires_grad=True)
                output = model(image)
                self.assertEqual(tuple(output.shape), (4, 10))
                self.assertClose(output, model(image.flatten(1)), rtol=0, atol=0)
                output.square().mean().backward()
                self.assertTrue(torch.isfinite(image.grad).all().item())
                self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all().item()
                                    for p in model.parameters()))
                model.eval()
                self.assertEqual(tuple(model(image[:1]).shape), (1, 10))

    def test_mnist_architecture_and_normal_initialization(self):
        baseline = MNISTMLP(seed=202)
        normalized = MNISTMLP(use_bn=True, seed=202)
        layers = self.affine_layers(baseline)
        self.assertEqual([(layer.in_features, layer.out_features) for layer in layers],
                         [(784, 100), (100, 100), (100, 100), (100, 10)])
        self.assertEqual(sum(isinstance(m, PaperBatchNorm) for m in normalized.modules()), 3)
        self.assertFalse(any(isinstance(m, nn.modules.batchnorm._BatchNorm)
                             for m in normalized.modules()))
        for layer in normalized.hidden_layers:
            self.assertIsNone(layer.bias)
        self.assertIsNotNone(normalized.classifier.bias)
        self.assertMatchedWeights(baseline, normalized)
        for layer in layers:
            self.assertAlmostEqual(layer.weight.std().item(), 0.01, delta=0.001)
            self.assertAlmostEqual(layer.weight.mean().item(), 0.0, delta=0.001)
        # Independently spell out the forward ordering: affine -> BN -> sigmoid.
        x = torch.randn(4, 784)
        expected = x
        for layer, norm in zip(normalized.hidden_layers, normalized.norms):
            expected = torch.sigmoid(paper_batch_norm_equations(
                layer(expected), norm.gamma, norm.beta, norm.eps
            ))
        self.assertClose(normalized(x), normalized.classifier(expected), rtol=2e-5, atol=2e-6)

    def test_global_seed_pairs_have_identical_weights(self):
        for model_type in (MNISTMLP, SmallInception):
            with self.subTest(model=model_type.__name__):
                torch.manual_seed(203)
                baseline = model_type(use_bn=False)
                torch.manual_seed(203)
                normalized = model_type(use_bn=True)
                self.assertMatchedWeights(baseline, normalized)

    def test_explicit_seed_preserves_cpu_rng_and_controls_initialization(self):
        for model_type in (MNISTMLP, SmallInception):
            with self.subTest(model=model_type.__name__):
                state = torch.get_rng_state().clone()
                first = model_type(seed=204)
                self.assertClose(torch.get_rng_state(), state, rtol=0, atol=0)
                second = model_type(seed=204)
                self.assertMatchedWeights(first, second)
                third = model_type(seed=205)
                self.assertFalse(torch.equal(self.affine_layers(first)[0].weight,
                                             self.affine_layers(third)[0].weight))

    def test_inception_output_shapes_and_backward_all_variants(self):
        configurations = (
            {"use_bn": False, "activation": "relu", "dropout": 0.4, "use_lrn": True},
            {"use_bn": True, "activation": "relu", "dropout": 0.4, "use_lrn": True},
            {"use_bn": True, "activation": "relu", "dropout": 0.0, "use_lrn": False},
            {"use_bn": True, "activation": "sigmoid", "dropout": 0.0, "use_lrn": False},
            {"use_bn": False, "activation": "sigmoid", "dropout": 0.4, "use_lrn": False},
        )
        for configuration in configurations:
            with self.subTest(configuration=configuration):
                model = SmallInception(seed=206, **configuration)
                x = torch.randn(2, 3, 48, 48, requires_grad=True)
                output = model(x)
                self.assertEqual(tuple(output.shape), (2, 10))
                output.square().mean().backward()
                self.assertTrue(torch.isfinite(x.grad).all().item())
                self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all().item()
                                    for p in model.parameters()))
                model.eval()
                with torch.no_grad():
                    self.assertEqual(tuple(model(x[:1]).shape), (1, 10))
                self.assertFalse(any(isinstance(m, nn.modules.batchnorm._BatchNorm)
                                     for m in model.modules()))

    def test_inception_topology(self):
        model = SmallInception(use_bn=True, activation="sigmoid", dropout=0, seed=207)
        x = model.stem(torch.randn(2, 3, 48, 48))
        self.assertEqual(tuple(x.shape), (2, 24, 12, 12))
        self.assertEqual(len(model.blocks), 3)
        for index, (channels, spatial) in enumerate(((40, 12), (52, 6), (80, 3))):
            block = model.blocks[index]
            specification = SmallInception.BLOCK_CHANNELS[index]
            branch_channels = (specification[0], specification[2], specification[4], specification[5])
            for branch, expected_channels in zip(
                (block.branch1, block.branch3, block.branch_double3, block.branch_pool),
                branch_channels,
            ):
                self.assertEqual(tuple(branch(x).shape), (2, expected_channels, spatial, spatial))
            self.assertEqual(len([m for m in block.branch_double3.modules() if isinstance(m, nn.Conv2d)]), 3)
            self.assertIsInstance(block.branch_pool[0], nn.AvgPool2d)
            x = block(x)
            self.assertEqual(tuple(x.shape), (2, channels, spatial, spatial))
            if index < 2:
                x = model.downsample(x)
        self.assertEqual(model.classifier.in_features, 80)
        convolutions = [m for m in model.modules() if isinstance(m, nn.Conv2d)]
        self.assertEqual(len(convolutions), 23)
        self.assertEqual(sum(isinstance(m, PaperBatchNorm) for m in model.modules()), 23)
        self.assertEqual(sum(isinstance(m, nn.Sigmoid) for m in model.modules()), 23)
        self.assertFalse(any(isinstance(m, nn.ReLU) for m in model.modules()))
        self.assertTrue(all(m.bias is None for m in convolutions))
        for module in model.modules():
            if isinstance(module, nn.Sequential) and len(module) and isinstance(module[0], nn.Conv2d):
                self.assertIsInstance(module[1], PaperBatchNorm)
                self.assertIsInstance(module[2], nn.Sigmoid)

    def test_inception_regularizers_and_matched_normal_initialization(self):
        baseline = SmallInception(use_lrn=True, seed=208)
        bn_baseline = SmallInception(use_bn=True, use_lrn=True, seed=208)
        bn_x = SmallInception(use_bn=True, activation="sigmoid", dropout=0, use_lrn=False, seed=208)
        self.assertMatchedWeights(baseline, bn_baseline)
        self.assertMatchedWeights(baseline, bn_x)
        self.assertIsInstance(baseline.dropout, nn.Dropout)
        self.assertEqual(baseline.dropout.p, 0.4)
        self.assertEqual(bn_baseline.dropout.p, 0.4)
        self.assertEqual(sum(isinstance(m, nn.LocalResponseNorm) for m in baseline.modules()), 2)
        self.assertEqual(sum(isinstance(m, nn.LocalResponseNorm) for m in bn_baseline.modules()), 2)
        self.assertIsInstance(bn_x.dropout, nn.Identity)
        self.assertFalse(any(isinstance(m, nn.LocalResponseNorm) for m in bn_x.modules()))
        for layer in self.affine_layers(baseline):
            expected_std = 0.05 if isinstance(layer, nn.Conv2d) else 0.01
            self.assertAlmostEqual(layer.weight.std().item(), expected_std, delta=expected_std * 0.15)
            self.assertAlmostEqual(layer.weight.mean().item(), 0.0, delta=expected_std * 0.15)

    def test_model_argument_validation(self):
        with self.assertRaises(ValueError):
            SmallInception(activation="tanh")
        with self.assertRaises(ValueError):
            SmallInception(dropout=-0.1)
        with self.assertRaises(ValueError):
            SmallInception(dropout=1.1)
        with self.assertRaises(ValueError):
            MNISTMLP()(torch.zeros(2, 783))
        with self.assertRaises(ValueError):
            SmallInception()(torch.zeros(2, 1, 48, 48))


if __name__ == "__main__":
    unittest.main()
