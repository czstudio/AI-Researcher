"""Pipeline integrity tests; real-data tests run when data have been prepared."""
import json
import sys
import unittest
from pathlib import Path
import torch
from torch import nn
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from train import augment, initialize, make_image_model
from models import MNISTMLP, PaperBatchNorm

class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config=json.loads((ROOT/'configs/reproduction.json').read_text())
        torch.set_num_threads(1)

    def test_locked_bn_config_matches_model(self):
        for dataset in ['mnist','imagenette']:
            cfg=self.config[dataset]
            model=MNISTMLP(True) if dataset=='mnist' else make_image_model('BN-x5',17,cfg)[0]
            for layer in model.modules():
                if isinstance(layer,PaperBatchNorm):
                    self.assertEqual(layer.eps,cfg['epsilon'])
                    self.assertEqual(layer.momentum,cfg['bn_new_stat_weight'])

    def test_training_initialization_matches_across_recipes(self):
        models=[]
        for name in self.config['imagenette']['variants']:
            model,_=make_image_model(name,17,self.config['imagenette'])
            models.append([m.weight for m in model.modules() if isinstance(m,(nn.Conv2d,nn.Linear))])
        for weights in models[1:]:
            for a,b in zip(models[0],weights):torch.testing.assert_close(a,b,rtol=0,atol=0)
        m1=MNISTMLP(False);m2=MNISTMLP(True)
        initialize(m1,'mnist',self.config['mnist'],17);initialize(m2,'mnist',self.config['mnist'],17)
        for a,b in zip(m1.hidden_layers,m2.hidden_layers):torch.testing.assert_close(a.weight,b.weight,rtol=0,atol=0)
        torch.testing.assert_close(m1.classifier.weight,m2.classifier.weight,rtol=0,atol=0)

    def test_augment_deterministic_finite_and_nonmutating(self):
        original=torch.randint(256,(5,3,48,48),dtype=torch.uint8)
        copy=original.clone()
        for modified in [False,True]:
            a=augment(original,torch.Generator().manual_seed(3),modified,self.config['imagenette'])
            b=augment(original,torch.Generator().manual_seed(3),modified,self.config['imagenette'])
            self.assertEqual(a.shape,(5,3,48,48));self.assertTrue(torch.isfinite(a).all())
            torch.testing.assert_close(a,b,rtol=0,atol=0)
        torch.testing.assert_close(original,copy,rtol=0,atol=0)

    def test_recipe_regularization_and_activation(self):
        cfg=self.config['imagenette']
        for name in cfg['variants']:
            m,modified=make_image_model(name,17,cfg)
            self.assertEqual(modified,name in ['BN-x5','BN-x30','BN-x5-Sigmoid'])
            self.assertEqual(m.use_bn,name!='Inception')
            self.assertEqual(m.activation,'sigmoid' if name.endswith('Sigmoid') else 'relu')
            self.assertEqual(any(isinstance(x,nn.LocalResponseNorm) for x in m.modules()),not modified)
            self.assertEqual(any(isinstance(x,nn.Dropout) for x in m.modules()),not modified)

    def test_real_split_integrity_if_available(self):
        path=ROOT/'data/imagenette/manifest.json'
        if not path.exists():self.skipTest('Data not downloaded yet')
        manifest=json.loads(path.read_text());cfg=self.config['imagenette']
        ids={split:{row['path'] for row in rows} for split,rows in manifest['splits'].items()}
        self.assertFalse(ids['train']&ids['dev']);self.assertFalse(ids['train']&ids['test']);self.assertFalse(ids['dev']&ids['test'])
        all_hashes=[r['sha256'] for rows in manifest['splits'].values() for r in rows]
        self.assertEqual(len(all_hashes),len(set(all_hashes)))
        data=torch.load(ROOT/'data/imagenette/subset.pt',weights_only=True,map_location='cpu')
        for split in ['train','dev','test']:
            self.assertEqual(len(ids[split]),cfg[split+'_per_class']*10)
            self.assertEqual(data[split+'_x'].dtype,torch.uint8)
            self.assertEqual(data[split+'_x'].shape,(len(ids[split]),3,48,48))
            for label in range(10):self.assertEqual((data[split+'_y']==label).sum().item(),cfg[split+'_per_class'])
        mn=torch.load(ROOT/'data/mnist/mnist.pt',weights_only=True,map_location='cpu')
        self.assertEqual(mn['train_x'].shape,(60000,784));self.assertEqual(mn['test_x'].shape,(10000,784))
        self.assertTrue(((mn['train_x']==0)|(mn['train_x']==1)).all())

if __name__=='__main__':unittest.main()
