"""Extract Figure1a PDF vector paths; optional provenance tool, no training dependency.
Requires preinstalled PyMuPDF (fitz). Result committed as source data for analysis.
Uses actual axis tick coordinates, not visual guesses. Line-width uncertainty is
not statistical uncertainty and does not recover unreported original run seeds.
"""
import csv
import json
from pathlib import Path
import fitz
from data import ROOT, digest


def main():
    source=ROOT/'sources/paper.pdf'
    doc=fitz.open(source);page=doc[5]
    drawings=page.get_drawings()
    # Coordinates verified against axis ticks and legend in the original PDF.
    x10k=88.23790740966797;x50k=133.89500427246094
    y70=78.8499755859375;y100=38.1729736328125
    def step(x):return 10000+(x-x10k)*40000/(x50k-x10k)
    def acc(y):return 70+(y70-y)*30/(y70-y100)
    curves={};rows=[]
    for name,color in [('Without-BN',(0.,0.,0.)),('With-BN',(0.,0.,1.))]:
        candidates=[d for d in drawings if d['color']==color and d['rect'].x0>=80 and d['rect'].x1<134 and d['rect'].y0>=38 and d['rect'].y1<79 and len(d['items'])>50]
        assert len(candidates)==1
        d=candidates[0];points=[]
        for item in d['items']:
            assert item[0]=='l'
            for point in [item[1],item[2]]:
                pair=(step(point.x),acc(point.y))
                if not points or pair!=points[-1]:points.append(pair)
        curves[name]={'points':points,'last_plotted_step':points[-1][0], 'last_plotted_accuracy':points[-1][1], 'half_linewidth_accuracy_pp':d['width']/2*30/(y70-y100)}
        rows.extend({'variant':name,'step':s,'accuracy':a} for s,a in points)
    metadata={'source_url':'https://arxiv.org/pdf/1502.03167','source_sha256':digest(source),'pdf_page_1based':6,'plot':'Figure1a','method':'PDF vector polyline extraction calibrated with 10K/50K and 0.7/1.0 ticks','axis_calibration':{'x10k':x10k,'x50k':x50k,'y70':y70,'y100':y100},'accuracy_uncertainty_pp':0.3,'note':'±0.3pp conservative rendering/digitization allowance, not run variance. Both traces stop short of plotted50K tick; do not extrapolate. Optimizer/init/std not reported.','curves':curves}
    (ROOT/'sources/published_mnist_vectors.json').write_text(json.dumps(metadata,indent=2))
    with open(ROOT/'sources/published_mnist_vectors.csv','w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['variant','step','accuracy']);writer.writeheader();writer.writerows(rows)
    print(json.dumps({name:{k:v for k,v in value.items() if k!='points'} for name,value in curves.items()},indent=2))

if __name__=='__main__':main()
