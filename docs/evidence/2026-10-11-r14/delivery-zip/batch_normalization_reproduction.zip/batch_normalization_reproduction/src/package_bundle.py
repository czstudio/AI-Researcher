"""Package code, source references, reports, raw logs and all CPU checkpoints.
Datasets are downloaded by entrypoint; excluded to avoid redistributing raw images.
"""
from pathlib import Path
import zipfile
from data import ROOT


def main():
    target=ROOT/'results/batch_normalization_reproduction.zip'
    excluded={'data','.git','__pycache__'}
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        count=0
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file():continue
            relative=path.relative_to(ROOT)
            if any(part in excluded for part in relative.parts):continue
            if path.suffix=='.zip' or path.name=='get-pip.py' or path.name in ['figure1_page.png','figure1_crop.png','page6.png','figure1.svg'] or path.suffix=='.pyc':continue
            archive.write(path,str(Path('batch_normalization_reproduction')/relative));count+=1
    print(f'Bundle: {target}, {count} files, {target.stat().st_size/1024/1024:.1f}MiB',flush=True)

if __name__=='__main__':main()
