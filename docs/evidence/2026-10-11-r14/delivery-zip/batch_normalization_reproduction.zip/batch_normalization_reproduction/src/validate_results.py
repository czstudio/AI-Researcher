"""Audit complete budgets, checkpoints, metrics and training curves on real data."""
import json
import math
from pathlib import Path
import torch
from data import ROOT,CONFIG,digest
from models import MNISTMLP
from train import evaluate,make_image_model
from analyze import load_csv


def main():
    config=json.loads(CONFIG.read_text())
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    report=[]
    for dataset in ['mnist','imagenette']:
        cache='mnist/mnist.pt' if dataset=='mnist' else 'imagenette/subset.pt'
        data=torch.load(ROOT/'data'/cache,weights_only=True,map_location='cpu')
        for seed in config['seeds']:
            folder=ROOT/'results'/dataset/f'seed_{seed}'
            summary=json.loads((folder/'summary.json').read_text())
            metadata=json.loads((folder/'run_config.json').read_text())
            assert metadata['device']=='cpu'
            assert metadata['config']==config[dataset]
            expected_data=([ROOT/'data/mnist/mnist.pt',ROOT/'data/mnist/provenance.json'] if dataset=='mnist' else [ROOT/'data/imagenette/subset.pt',ROOT/'data/imagenette/manifest.json'])
            current_hashes={str(p.relative_to(ROOT)):digest(p) for p in expected_data}
            assert metadata['data_sha256']==current_hashes, f'Dataset changed since training: {folder}'
            for name,result in summary.items():
                trace=load_csv(folder/result['trace'])
                checkpoint=torch.load(folder/f'{name}.pt',weights_only=True,map_location='cpu')
                model=MNISTMLP(use_bn=name=='With-BN',seed=seed) if dataset=='mnist' else make_image_model(name,seed,config[dataset])[0]
                model.load_state_dict(checkpoint['state_dict'])
                expected=result['final_test'] if dataset=='mnist' else result['selected_test']
                actual=evaluate(model,data['test_x'],data['test_y'],image=dataset=='imagenette')
                for metric in ['top1','top5','loss']:
                    assert math.isclose(expected[metric],actual[metric],rel_tol=1e-8,abs_tol=1e-8),(dataset,seed,name,metric,expected,actual)
                if dataset=='mnist':
                    assert len(trace)==51 and trace[-1]['step']==50000
                    assert result['steps']==50000
                    assert math.isclose(trace[-1]['test_top1'],actual['top1'])
                else:
                    assert len(trace)==61 and trace[-1]['epoch']==60 and result['steps']==2820
                    selected=evaluate(model,data['dev_x'],data['dev_y'],image=True)
                    assert selected['top1']==result['best_dev_top1']
                    assert result['best_dev_top1']==max(row['dev_top1'] for row in trace[1:])
                    assert checkpoint['best_epoch']==result['best_epoch']
                    model.load_state_dict(checkpoint['last_state_dict'])
                    last=evaluate(model,data['test_x'],data['test_y'],image=True)
                    for metric in ['top1','top5','loss']:
                        assert math.isclose(last[metric],result['last_test'][metric],rel_tol=1e-8,abs_tol=1e-8)
                assert all(value.device.type=='cpu' for value in checkpoint['state_dict'].values())
                report.append({'dataset':dataset,'seed':seed,'variant':name,'status':'PASS','reloaded_test_top1':actual['top1'],'trace_rows':len(trace)})
                print(f'PASS checkpoint/metrics/budget {dataset} seed={seed} {name} test@1={actual["top1"]:.2f}',flush=True)
    assert len(report)==21
    (ROOT/'results/validation.json').write_text(json.dumps({'status':'PASS','audited_runs':len(report),'checks':report},indent=2))
    print('VALIDATION PASS: all21complete CPU-only runs reloaded and re-evaluated',flush=True)

if __name__=='__main__':main()
