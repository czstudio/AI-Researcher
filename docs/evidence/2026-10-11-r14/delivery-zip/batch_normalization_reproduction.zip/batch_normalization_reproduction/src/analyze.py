"""Generate source-anchored fidelity report, machine-readable tables and figures.
No imputed unpublished paper metrics; proxy ImageNet gaps always non-comparable.
"""
import csv
import json
import platform
from pathlib import Path
import statistics
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from data import ROOT, CONFIG, digest
from run_experiments import fingerprint

RESULTS=ROOT/'results'
FIGURES=RESULTS/'figures'
VARIANTS=['Inception','BN-Baseline','BN-x5','BN-x30','BN-x5-Sigmoid']
MNAMES=['Without-BN','With-BN']

def ms(values):
    values=[float(v) for v in values]
    return {'mean':statistics.mean(values),'sd':statistics.stdev(values) if len(values)>1 else 0.,'values':values}

def fmt(stat,digits=2):return f'{stat["mean"]:.{digits}f} ± {stat["sd"]:.{digits}f}'

def load_csv(path):
    with open(path) as f:return [{k:float(v) if v else float('nan') for k,v in row.items()} for row in csv.DictReader(f)]

def save_csv(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def first_crossing(trace,key,target):
    return next((int(row['step']) for row in trace if row[key]>=target),None)

def configure_style(dark=False):
    surface='#1a1a19' if dark else '#fcfcfb'
    ink='#ffffff' if dark else '#0b0b0b'
    secondary='#c3c2b7' if dark else '#52514e'
    grid='#2c2c2a' if dark else '#e1e0d9'
    plt.rcParams.update({'figure.facecolor':surface,'axes.facecolor':surface,'savefig.facecolor':surface,
       'text.color':ink,'axes.labelcolor':secondary,'xtick.color':secondary,'ytick.color':secondary,
       'axes.edgecolor':grid,'grid.color':grid,'grid.linewidth':.55,
       'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,
       'axes.spines.top':False,'axes.spines.right':False,'lines.linewidth':2.,
       'legend.frameon':False,'figure.dpi':150})
    return ['#3987e5','#d95926'] if dark else ['#2a78d6','#eb6834']

def make_plots(traces,source,seeds):
    FIGURES.mkdir(exist_ok=True)
    for dark in [False,True]:
        colors=configure_style(dark);suffix='_dark' if dark else ''
        fig,axes=plt.subplots(1,2,figsize=(12.6,4.5),layout='constrained')
        for panel,ax in enumerate(axes):
            for j,name in enumerate(MNAMES):
                rows=[traces['mnist'][seed][name] for seed in seeds]
                steps=np.array([r['step'] for r in rows[0]])
                accuracies=np.array([[r['test_top1'] for r in rs] for rs in rows])
                mean=accuracies.mean(0);sd=accuracies.std(0,ddof=1)
                ax.plot(steps,mean,color=colors[j],linestyle='-' if j==0 else '--',label=f'{name}: reproduction')
                ax.fill_between(steps,mean-sd,mean+sd,color=colors[j],alpha=.11,linewidth=0)
                pts=np.array(source['curves'][name]['points'])
                ax.plot(pts[:,0],pts[:,1],color=colors[j],linestyle=':',linewidth=1.5,label=f'{name}: paper vector')
                if panel==1:
                    ax.annotate(f'{name} {mean[-1]:.2f}%',xy=(50000,mean[-1]),xytext=(28000,98.12+j*.30),color=plt.rcParams['text.color'],fontsize=9,arrowprops={'arrowstyle':'-','color':colors[j],'lw':.8})
            ax.set(xlabel='Training updates',ylabel='Test top-1 accuracy (%)',xlim=(0,51000))
            ax.set_xticks([0,10000,20000,30000,40000,50000],['0','10k','20k','30k','40k','50k'])
            ax.grid(axis='y');ax.set_axisbelow(True)
        axes[0].set_ylim(70,100);axes[0].set_title('Figure 1a: matched architecture and update budget')
        axes[1].set_ylim(95.5,98.8);axes[1].set_title('Late accuracy: numerical gap remains')
        axes[0].legend(loc='lower right',fontsize=8)
        axes[1].legend(loc='lower right',fontsize=8)
        fig.suptitle('MNIST sigmoid MLP • three seeds; shaded band = ±1 sample SD',fontsize=13)
        fig.savefig(FIGURES/f'mnist_figure1{suffix}.png');fig.savefig(FIGURES/f'mnist_figure1{suffix}.svg');plt.close(fig)
        # Five facets rather than five potentially confusable categorical lines.
        fig,axes=plt.subplots(2,3,figsize=(12.6,7.2),layout='constrained')
        for ax,name in zip(axes.flat,VARIANTS):
            rows=[traces['imagenette'][seed][name] for seed in seeds]
            epochs=np.array([r['epoch'] for r in rows[0]])
            acc=np.array([[r['dev_top1'] for r in rs] for rs in rows])
            mean=acc.mean(0);sd=acc.std(0,ddof=1)
            ax.plot(epochs,mean,color=colors[0],label='Mean dev accuracy')
            ax.fill_between(epochs,mean-sd,mean+sd,color=colors[0],alpha=.15,linewidth=0)
            ax.set(title=name,xlabel='Epoch',ylabel='Development top-1 (%)',ylim=(0,100),xlim=(0,60))
            ax.grid(axis='y');ax.set_axisbelow(True)
            ax.text(.04,.94,f'Final mean: {mean[-1]:.1f}%',transform=ax.transAxes,va='top',fontsize=9)
        axes.flat[-1].axis('off')
        axes.flat[-1].text(0,.9,'REAL IMAGENETTE PROXY\n\n10 classes • 48px • 1500 train\n500 development • 1000 held-out test\n3 independent seeds • 60 full epochs\n\nLine: mean development accuracy\nBand: ±1 sample SD\n\nNot 1000-class ImageNet parity.\nSee comparison.csv for table view.',va='top',fontsize=11,linespacing=1.6)
        fig.suptitle('Small Inception: BN recipe comparison on real images',fontsize=14)
        fig.savefig(FIGURES/f'imagenette_training{suffix}.png');fig.savefig(FIGURES/f'imagenette_training{suffix}.svg');plt.close(fig)

def main():
    config=json.loads(CONFIG.read_text());seeds=config['seeds']
    reference=json.loads((ROOT/'sources/published_references.json').read_text())
    source=json.loads((ROOT/'sources/published_mnist_vectors.json').read_text())
    summaries={};traces={}
    for dataset,names in [('mnist',MNAMES),('imagenette',VARIANTS)]:
        summaries[dataset]={};traces[dataset]={}
        for seed in seeds:
            folder=RESULTS/dataset/f'seed_{seed}'
            summary=json.loads((folder/'summary.json').read_text())
            assert json.loads((folder/'run_config.json').read_text())['config']==config[dataset], f'Config mismatch {folder}'
            assert set(summary)==set(names),f'Incomplete summary {folder}'
            summaries[dataset][seed]=summary
            traces[dataset][seed]={name:load_csv(folder/summary[name]['trace']) for name in names}
            for name in names:
                trace=traces[dataset][seed][name]
                budget=config[dataset]['steps'] if dataset=='mnist' else config[dataset]['epochs']
                budgetkey='step' if dataset=='mnist' else 'epoch'
                assert trace[-1][budgetkey]==budget,f'Incomplete training {folder} {name}'
                assert all(np.isfinite(row['test_top1' if dataset=='mnist' else 'dev_top1']) for row in trace)
    stats={'seeds':seeds,'mnist':{},'imagenette_proxy':{},'published':reference}
    comparison=[];perseed=[];curves=[];thresholds=[];matched=[]
    for name in MNAMES:
        values=[summaries['mnist'][seed][name]['final_test']['top1'] for seed in seeds]
        s=ms(values);published=source['curves'][name]['last_plotted_accuracy']
        stats['mnist'][name]={'final_test_top1':s,'published_last_plotted_top1':published,'published_last_plotted_step':source['curves'][name]['last_plotted_step'],'signed_gap_pp':s['mean']-published}
        comparison.append({'dataset':'MNIST','variant':name,'published_max_or_last_top1':published,'reproduced_primary_mean':s['mean'],'reproduced_primary_sd':s['sd'],'selected_test_mean':s['mean'],'selected_test_sd':s['sd'],'signed_primary_gap_pp':s['mean']-published,'numerically_comparable':'approximate_only_last_paper_point_not_exact_50k'})
        for seed in seeds:
            summ=summaries['mnist'][seed][name]
            perseed.append({'dataset':'MNIST','seed':seed,'variant':name,'primary_top1':summ['final_test']['top1'],'selected_test_top1':summ['final_test']['top1'],'selected_test_top5':summ['final_test']['top5'],'final_test_top1':summ['final_test']['top1'],'selected_epoch_or_step':50000,'seconds':summ['seconds']})
            for target in [90,95,97]:
                cross=first_crossing(traces['mnist'][seed][name],'test_top1',target)
                thresholds.append({'dataset':'MNIST','seed':seed,'variant':name,'target_accuracy':target,'target_kind':'fixed_test_threshold','updates_to_target':cross,'eval_resolution_updates':1000})
        sourcepoints=np.array(source['curves'][name]['points'])
        assert np.all(np.diff(sourcepoints[:,0])>=0)
        for step in [10000,20000,30000,40000]:
            assert sourcepoints[0,0]<=step<=sourcepoints[-1,0], 'Never extrapolate paper curves'
            paper=float(np.interp(step,sourcepoints[:,0],sourcepoints[:,1]))
            vals=[next(r['test_top1'] for r in traces['mnist'][seed][name] if r['step']==step) for seed in seeds]
            sstep=ms(vals)
            matched.append({'variant':name,'step':step,'paper_vector_top1':paper,'reproduction_mean':sstep['mean'],'reproduction_sd':sstep['sd'],'gap_pp':sstep['mean']-paper})
    mnist_delta=ms([summaries['mnist'][s]['With-BN']['final_test']['top1']-summaries['mnist'][s]['Without-BN']['final_test']['top1'] for s in seeds])
    stats['mnist']['paired_bn_gain_pp']=mnist_delta
    for name in VARIANTS:
        values=[summaries['imagenette'][seed][name] for seed in seeds]
        best=ms([v['best_dev_top1'] for v in values]);test=ms([v['selected_test']['top1'] for v in values]);test5=ms([v['selected_test']['top5'] for v in values]);last=ms([v['last_test']['top1'] for v in values])
        published=reference['imagenet_figure3'][name]['max_top1']
        stats['imagenette_proxy'][name]={'best_dev_top1':best,'selected_test_top1':test,'selected_test_top5':test5,'last_test_top1':last,'published_imagenet_max_top1':published,'signed_dev_gap_pp_noncomparable':best['mean']-published}
        comparison.append({'dataset':'Imagenette_PROXY_NOT_IMAGENET','variant':name,'published_max_or_last_top1':published,'reproduced_primary_mean':best['mean'],'reproduced_primary_sd':best['sd'],'selected_test_mean':test['mean'],'selected_test_sd':test['sd'],'signed_primary_gap_pp':best['mean']-published,'numerically_comparable':'NO_10classes48px1500train_small_architecture'})
        for seed in seeds:
            summ=summaries['imagenette'][seed][name]
            perseed.append({'dataset':'Imagenette_PROXY','seed':seed,'variant':name,'primary_top1':summ['best_dev_top1'],'selected_test_top1':summ['selected_test']['top1'],'selected_test_top5':summ['selected_test']['top5'],'final_test_top1':summ['last_test']['top1'],'selected_epoch_or_step':summ['best_epoch'],'seconds':summ['seconds']})
            target=summaries['imagenette'][seed]['Inception']['best_dev_top1']
            cross=first_crossing(traces['imagenette'][seed][name],'dev_top1',target)
            thresholds.append({'dataset':'Imagenette_PROXY','seed':seed,'variant':name,'target_accuracy':target,'target_kind':'same_seed_proxy_baseline_best_dev','updates_to_target':cross,'eval_resolution_updates':47})
    for dataset,names,metric in [('mnist',MNAMES,'test_top1'),('imagenette',VARIANTS,'dev_top1')]:
        for name in names:
            runs=[traces[dataset][seed][name] for seed in seeds]
            for i,row in enumerate(runs[0]):
                s=ms([run[i][metric] for run in runs])
                curves.append({'dataset':dataset,'variant':name,'step':row['step'],'epoch':row['epoch'],'mean_top1':s['mean'],'sd_top1':s['sd'],'metric':metric})
    save_csv(RESULTS/'comparison.csv',comparison);save_csv(RESULTS/'per_seed_metrics.csv',perseed)
    save_csv(RESULTS/'mean_training_curves.csv',curves);save_csv(RESULTS/'threshold_steps.csv',thresholds)
    save_csv(RESULTS/'mnist_matched_steps.csv',matched)
    (RESULTS/'aggregate_metrics.json').write_text(json.dumps(stats,indent=2))
    make_plots(traces,source,seeds)
    # Data provenance and all completed results are retained for audit.
    manifest=json.loads((ROOT/'data/imagenette/manifest.json').read_text())
    (RESULTS/'imagenette_manifest.json').write_text(json.dumps(manifest,indent=2))
    (RESULTS/'mnist_provenance.json').write_text((ROOT/'data/mnist/provenance.json').read_text())
    params_m=summaries['mnist'][seeds[0]]['Without-BN']['parameters']
    params_i=summaries['imagenette'][seeds[0]]['Inception']['parameters']
    total_seconds=sum(row['seconds'] for row in perseed)
    mrows='\n'.join(f'| {name} | ≈{stats["mnist"][name]["published_last_plotted_top1"]:.2f} (±0.3 digitization) | {fmt(stats["mnist"][name]["final_test_top1"])} | {stats["mnist"][name]["signed_gap_pp"]:+.2f} |' for name in MNAMES)
    irows='\n'.join(f'| {name} | {reference["imagenet_figure3"][name]["max_top1"]:.1f} | {fmt(stats["imagenette_proxy"][name]["best_dev_top1"])} | {fmt(stats["imagenette_proxy"][name]["selected_test_top1"])} | {fmt(stats["imagenette_proxy"][name]["last_test_top1"])} | {stats["imagenette_proxy"][name]["signed_dev_gap_pp_noncomparable"]:+.2f} |' for name in VARIANTS)
    p_rows='\n'.join(f'| {r["dataset"]} | {r["seed"]} | {r["variant"]} | {r["primary_top1"]:.2f} | {r["selected_test_top1"]:.2f} | {r["selected_epoch_or_step"]} |' for r in perseed)
    matched_rows='\n'.join(f'| {r["variant"]} | {int(r["step"])} | ≈{r["paper_vector_top1"]:.2f} | {r["reproduction_mean"]:.2f} ± {r["reproduction_sd"]:.2f} | {r["gap_pp"]:+.2f} |' for r in matched)
    speed_rows=[]
    for name in VARIANTS:
        ratios=[];crossvals=[]
        for seed in seeds:
            target=summaries['imagenette'][seed]['Inception']['best_dev_top1']
            base=first_crossing(traces['imagenette'][seed]['Inception'],'dev_top1',target)
            bn=first_crossing(traces['imagenette'][seed][name],'dev_top1',target)
            crossvals.append(str(bn) if bn is not None else 'not reached')
            if bn:ratios.append(base/bn)
        published=reference['imagenet_figure3'][name]['steps_to_72_2']
        speed_rows.append(f'| {name} | {published/1e6:.1f}M' if published else f'| {name} | not reached')
        speed_rows[-1]+=f' | {", ".join(crossvals)} | {fmt(ms(ratios)) if ratios else "not reached"} |'
    threshold_rows=[]
    for name in MNAMES:
        for target in [90,95,97]:
            vals=[first_crossing(traces['mnist'][seed][name],'test_top1',target) for seed in seeds]
            threshold_rows.append(f'| {name} | {target}% | {", ".join(str(v) if v is not None else "not reached" for v in vals)} |')
    rank_paper=sorted(VARIANTS,key=lambda n:reference['imagenet_figure3'][n]['max_top1'],reverse=True)
    rank_proxy=sorted(VARIANTS,key=lambda n:stats['imagenette_proxy'][n]['best_dev_top1']['mean'],reverse=True)
    pairedrows=[];proxy_gains={}
    for name in VARIANTS[1:]:
        delta=ms([summaries['imagenette'][s][name]['selected_test']['top1']-summaries['imagenette'][s]['Inception']['selected_test']['top1'] for s in seeds])
        proxy_gains[name]=delta
        pairedrows.append(f'| {name} vs Inception | {fmt(delta)} |')
    baseline_test=stats['imagenette_proxy']['Inception']['selected_test_top1']['mean']
    bn_test=stats['imagenette_proxy']['BN-Baseline']['selected_test_top1']['mean']
    best_proxy=rank_proxy[0]
    repeat_path=RESULTS/'repeatability.json'
    repeat_note=('Two independent full-budget executions, including a fresh entrypoint --force run, gave exactly equal endpoint accuracies/losses and checkpoint-selection epochs for all 21 runs; see repeatability.json.' if repeat_path.exists() and json.loads(repeat_path.read_text()).get('status')=='PASS' and json.loads(repeat_path.read_text()).get('fingerprint')==fingerprint(config) else 'Fresh-run repeatability verification is not yet recorded; no exact rerun claim is made.')
    paper_gap=source['curves']['With-BN']['last_plotted_accuracy']-source['curves']['Without-BN']['last_plotted_accuracy']
    mnist_early90={name:[first_crossing(traces['mnist'][s][name],'test_top1',90) for s in seeds] for name in MNAMES}
    mnist_early95={name:[first_crossing(traces['mnist'][s][name],'test_top1',95) for s in seeds] for name in MNAMES}
    early_comment=(f'At 90%, first observed crossings are {mnist_early90["Without-BN"]} without BN and {mnist_early90["With-BN"]} with BN; at 95%, they are {mnist_early95["Without-BN"]} versus {mnist_early95["With-BN"]}. The original pronounced early-optimization speedup is therefore not established by the endpoint improvement alone.')
    report=f'''# Batch Normalization reproduction: fidelity report

## Executive verdict

**MNIST: partial quantitative reproduction, with matched architecture/data/update budget.** At 50,000 updates, BN has a paired accuracy gain of **{fmt(mnist_delta)} percentage points** across three fixed seeds. The source graph's last plotted points are approximately97.23% without BN and98.16% with BN (±0.3pp digitization allowance), implying about{paper_gap:.2f}pp gain. The observed gain is smaller. Optimizer and initialization assumptions materially affect the trajectories; this is not an exact training-curve reproduction.

**ImageNet: declared real-data, small-scale proxy only, not a reproduction of ImageNet absolute accuracy.** All five recipes were independently trained for60 epochs on real Imagenette images. The paper ordering is **{' > '.join(rank_paper)}**; proxy maximum-development ordering is **{' > '.join(rank_proxy)}**. Adding BN alone changes held-out accuracy from **{baseline_test:.2f}% to {bn_test:.2f}%**, a paired gain of **{fmt(proxy_gains['BN-Baseline'])}pp**. The best maximum-development recipe is **{best_proxy}**, so the source's higher final BN-x30 accuracy is not recovered as the proxy mean ranking. The close x5/x30 estimates are not a statistically established ordering with only three seeds. The original74.8% top-1,7.82% top-5 error,14x training-speedup and4.82% ensemble test-error claims are **not reproduced or validated by this reduced task**.

## 1. Source interpretation and core contributions

Source: Ioffe & Szegedy(2015), [arXiv1502.03167](https://arxiv.org/abs/1502.03167), cross-checked against the [published ICML paper](https://proceedings.mlr.press/v37/ioffe15.html). PDFs and extracted text are included in `sources/`.

Two corrections to the request: Figure1a is a **784→100→100→100→10 sigmoid fully connected network, not convolutional LeNet**. Neither downloaded paper version labels “Table1 columnB”; the ImageNet target is interpreted as the **maximum single-crop accuracy column of Figure3**. Every five-row value is reproduced in the comparison table as a reference, not as a measured result on our dataset. Figure4 separately gives BN-Inception single-crop25.2% top-1 error and7.82% top-5 error.

Priority contributions are(1)differentiable per-feature normalization with learned gamma/beta;(2)unbiased running-variance inference;(3)BN before sigmoid/ReLU and channelwise batch/spatial statistics;(4)faster/higher-accuracy MNIST learning; and(5)higher-LR and reduced-regularization ImageNet recipes. Accuracy results alone do not identify the causal mechanism or establish that reducing internal covariate shift explains BN's benefit.

## 2. Scope, implementation and setup

**In scope:** independent PyTorch implementation, CPU-only float32, from-scratch weights, full real MNIST, all five single-network recipes on a declared downscaled ImageNet subset, three paired seeds, quantitative comparisons, complete logs/checkpoints/scripts. **Out of scope:** full1000-class ImageNet, original13.6M-parameter network and distributed schedule, ensemble/multicrop/server submission, Figure1b/c activation distributions, causal explanation. The detailed source-component→module→config→script mapping is in [`REPRODUCTION_PLAN.md`](../REPRODUCTION_PLAN.md).

| Setup | MNIST | ImageNet proxy |
|---|---|---|
| Data | Full canonical60000train/10000test | Real Imagenettev2 ten ImageNet classes |
| Input | Binary28×28, raw/255>.5 | Center-cropped48×48 RGB, normalization |
| Network | Paper's three100-unit sigmoid layers | Three independent four-branch Inception modules, double3×3 branch |
| Baseline parameters | {params_m:,} | {params_i:,} |
| Training | 50000updates, batch60 =50passes | 60epochs, batch32,47updates/epoch =2820updates |
| Optimizer | SGD lr.1,momentum.9 | SGD base lr.01,momentum.9; LR multipliers1/5/30 |
| Regularization | No dropout/decay | Baseline dropout.4/LRN/L2.0005; modified no dropout/LRN,L2÷5 |
| Schedule | Constant LR | Exponential×.1 per240baseline epochs/per40modified epochs |
| Repeats | Seeds17,29,43 | Same seeds, same fixed split |
| Evaluation | Fixed final-step test; interim test trace | Test selected and final checkpoints after training/dev-selection; repeated for verification |

Dataset split:1500train/500development from disjoint official training images,1000test from official validation images. Every class has150/50/100examples; paths and SHA256s are in `imagenette_manifest.json`, selection seed2026. Archive SHA256:`{manifest['archive_sha256']}`. No synthetic data or pretrained models are used. The test is never used for tuning/checkpoint selection. Development maxima can nevertheless overestimate generalization; the held-out column is the stronger evidence. Seeds measure initialization/order variability on **one fixed data split**, not dataset-sampling uncertainty.

CPU runtime: Python{platform.python_version()}, PyTorch{torch.__version__}, NumPy{np.__version__}, Matplotlib{matplotlib.__version__}. Resource quota3CPU cores/8GiB; up to3one-thread runs concurrently. Sum of measured run wall times is{total_seconds/60:.1f}minutes; parallel scheduling means this is not total elapsed job time. Full dependency snapshot:`environment_freeze.txt`.

## 3. MNIST Figure1a

**Primary metric:** fixed50k-update test accuracy, mean±sampleSD over3seeds. Paper values are last visible plotted points, **not an exact published50k table**. The baseline curve's last vector point is at≈44.1k updates; BN's at≈49.1k. No extrapolation to50k is performed.

| Network | Paper last plotted test accuracy(%) | Reproduced50k test accuracy(%) | Descriptive gap(pp) |
|---|---:|---:|---:|
{mrows}

![Figure1a reproduction with paper vector curves](figures/mnist_figure1.png)

For a same-update comparison, source polylines are interpolated **only inside their observed domain**:

| Network | Updates | Paper graph accuracy(%) | Reproduced mean±SD(%) | Gap(pp) |
|---|---:|---:|---:|---:|
{matched_rows}

Digitization is reproducible via `src/digitize_paper.py`: actual PDF vector paths are calibrated using10k/50k and70%/100%ticks; the original0.65-point curve width corresponds to about±0.24pp, conservatively rounded to±0.3pp. This allowance is not statistical uncertainty. Source points/calibration/hash are retained in `sources/published_mnist_vectors.*`. There are no exact source MNIST numbers to compare beyond these graph estimates.

First observed fixed test threshold crossings, resolution1000updates; seed order17,29,43. Crossings are not interpolated and are not necessarily sustained:

| Network | Target | Updates per seed |
|---|---:|---|
{chr(10).join(threshold_rows)}

{early_comment}

Interpretation: compare the endpoint gain and matched-step rows, not just final accuracy. A baseline that learns substantially faster than the source baseline indicates a gap in the missing optimizer/initialization details even when final accuracy is close. No post-hoc test-based tuning was done.

## 4. ImageNet classification maximum-accuracy column: proxy comparison

Paper reference metric is maximum **1000-class ImageNet validation** top-1 accuracy. Proxy primary analog is maximum **10-class development** accuracy; the development-selected checkpoint is evaluated on a separate held-out test. All percentages use single deterministic crops. **The signed gap column is numerically descriptive and NOT a meaningful same-benchmark accuracy difference.**

| Recipe | Paper ImageNet max top-1(%) | Proxy best-dev mean±SD(%) | Proxy selected-test mean±SD(%) | Proxy final-test mean±SD(%) | Dev minus paper(pp; NOT comparable) |
|---|---:|---:|---:|---:|---:|
{irows}

![Real Imagenette proxy learning curves](figures/imagenette_training.png)

Paired held-out top-1 gains across the same seed and split:

| Comparison | Test accuracy gain(pp),mean±SD |
|---|---:|
{chr(10).join(pairedrows)}

Steps-to-accuracy fidelity: the original31M/13.3M/2.1M/2.7M values target72.2% on1000classes. Here each seed targets **its own proxy Inception maximum development accuracy**, so ratios assess a local training trend only. Evaluation interval is47updates; comparisons are noisy and based on first observed crossing. Same72.2% on ten classes would not establish original training acceleration.

| Recipe | Paper steps to72.2%ImageNet | Proxy updates to same-seed baseline-best(seed17,29,43) | Proxy baseline/recipe update ratio,mean±SD |
|---|---:|---|---:|
{chr(10).join(speed_rows)}

Proxy top-5 is included in `aggregate_metrics.json` and `per_seed_metrics.csv`, but it is particularly non-comparable: chance top-5 is50% for ten classes versus0.5% for1000. Do not interpret proxy top-5 gains as replication of7.82% single-crop or4.82%ensemble error.

## 5. Fidelity assessment and deviations

| Claim/component | Fidelity status | Reason |
|---|---|---|
| BN equations, differentiability, affine transform | High implementation fidelity | Independent equations and optimized primitive agree numerically; forward/backward/gradcheck verified |
| Training biased variance / inference unbiased variance | High implementation fidelity | Moving statistics and batch-invariant inference tested |
| MNIST architecture,data,batch,update budget | High | Same dimensions/nonlinearity and full dataset; binary-threshold convention assumed |
| MNIST numerical trajectories/endpoints | Partial | Smaller gain and trajectory gaps; optimizer/init/std not published |
| Convolutional BN and double3×3 Inception branches | Mechanism faithful | All proxy conv nonlinearities preceded by BN when enabled |
| ImageNet absolute accuracy or original ranking | Not established | Ten-class48px subset, small architecture, changed optimizer scale and60epoch budget |
| Original14x/7%update budget headline | Not reproduced | No full distributed ImageNet experiment; proxy speed ratios have a different target |
| Sigmoid deep-network viability | Proxy evidence only | Its actual curve/results retained, not claimed original69.8% parity |
| Ensemble/server top-5 error | Out of scope | No ensemble,144crops or server access |
| Internal-covariate-shift causal explanation | Not tested | Predictive accuracy cannot resolve mechanism |

All assumptions were recorded before final runs in `REPRODUCTION_PLAN.md` and locked in `configs/reproduction.json`. Critical unreported details: MNIST optimizer/LR/momentum/Gaussian std, binary threshold, epsilon, moving-average coefficient; ImageNet exact momentum/L2/decay/initialization/augmentation. CPU deviations: synchronous single-model training instead of distributed asynchronous SGD; three-module standard3×3stem/maxpool proxy instead of paper's ten-module/separable7×7stem architecture. Modern Kaiming initialization for proxy convolutions(including sigmoid); normal.01 classifier. Original baselineLR.0015 becomes.01, preserving5x/30xratios, not absolute rates. L2 excludes biases and BN affine parameters. Photometric distortion is simplified to brightness/contrast(.7–1.3baseline vs.9–1.1modified) and crop/flip. All models use equally thorough full shuffling, so the source's extra1ppwithin-shard-shuffle improvement is not separately tested. Cache resizing changes augmentations and loses original high-resolution information. Sixty epochs is the complete declared proxy budget, not original training convergence.

Implementation uses PyTorch's `F.batch_norm` CPU kernel for throughput and independently implemented differentiable normalization equations for correctness testing; no official/model-reference repository is imported. Package/runtime initially lacked advertised PyTorch/pip; CPU dependencies were installed in the configured writable `.pypackages`, without a virtual environment. Installation attempts/errors and successful output are logged.

## 6. Per-seed results and reproducibility

| Dataset | Seed | Recipe | Primary accuracy(%) | Selected/final-MNIST test(%) | Selected epoch/step |
|---|---:|---|---:|---:|---:|
{p_rows}

Run from any working directory:

```bash
bash /home/novix/workspace/project/entrypoint.sh
# Fully retrain from scratch instead of reusing complete validated runs:
bash /home/novix/workspace/project/entrypoint.sh --force
```

The entrypoint installs/checks CPU dependencies, runs the numerical/data-integrity tests, fetches real datasets if absent, executes all training/evaluation, and regenerates tables/figures/report. Default reuse is transparent and guarded by a config+training-code+dataset-cache/provenance SHA256 fingerprint and expected output presence. `--force` executes all training again with fixed seeds. Training caches are not substituted for missing data; missing real sources cause a clear failure. {repeat_note} Identical runtime is expected to reproduce deterministic metrics; wall-clock times vary. Cross-version/platform bitwise reproducibility is not asserted.

Artifacts: `comparison.csv`, `per_seed_metrics.csv`, `mnist_matched_steps.csv`, `mean_training_curves.csv`, `threshold_steps.csv`, `aggregate_metrics.json`; raw50k/60epochCSVtraces and per-seed `summary.json`, `run_config.json`, `completion.json`, `train.log`; full selected and last-image-model checkpoint states; immutable split/source manifests; source PDFs/reference values; environment snapshot;22unit tests. Light/darkPNG/SVGfigures and underlyingCSVtable views are provided; labels/line styles distinguish entities without relying only on color.
## 7. Recommended next steps

1. Obtain the original MNIST optimizer,Gaussian variance and binary-input convention from the authors; preregister a training-only/dev-only sensitivity study over these missing settings, without tuning on the final test curve.
2. Run the appendix architecture on a larger1000-class ImageNet subset at224px, preserving all classes. Add data-scale/width/resolution ablations before claiming that the proxy trend transfers.
3. With sufficient compute/data access, use fullImageNet and the published absoluteLR/distributed scheduling details; evaluate exact single-crop protocol. Only this can validate74.8%/14xheadline claims.
4. Add controlled one-change-at-a-time BN recipe ablations and higher-LR non-BN controls; the five bundled recipes do not independently identify each change's contribution.
5. Increase seeds and use several predeclared data splits for proxy uncertainty; three fixed-split seeds are useful diagnostics, not robust significance evidence.
6. Study training-time activation distributions/gradient behavior separately if testing internal-covariate-shift explanations is desired.

## References

- Ioffe,S.&Szegedy,C.(2015). *Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift*. ICML,PMLR37:448–456. https://proceedings.mlr.press/v37/ioffe15.html ; https://arxiv.org/abs/1502.03167 .
- FastAI. *Imagenette*: real ten-class ImageNet subset. https://github.com/fastai/imagenette ; https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz .
- MNIST canonical IDX mirrors: https://storage.googleapis.com/cvdf-datasets/mnist/ and https://ossci-datasets.s3.amazonaws.com/mnist/ . Individual source checksums in `mnist_provenance.json`.
'''
    # Presentation-only spacing fixes for compact mathematical prose in templates.
    typography={
        'Figure1':'Figure 1', 'Figure2':'Figure 2', 'Figure3':'Figure 3', 'Figure4':'Figure 4',
        'Table1':'Table 1', 'columnB':'column B', 'arXiv1502.03167':'arXiv:1502.03167',
        'for60 epochs':'for 60 epochs', 'for60epochs':'for 60 epochs', '60epochs':'60 epochs',
        '50k-update':'50k-update', '50k table':'50k table', '50000updates':'50,000 updates',
        '60epoch':'60-epoch', '50k/60-epochCSVtraces':'50k/60-epoch CSV traces',
        '60000train/10000test':'60,000 train / 10,000 test',
        '1500train/500development':'1,500 train / 500 development',
        '1000test':'1,000 test', '150/50/100examples':'150/50/100 examples',
        'ten100':'ten 100', 'three100-unit':'three 100-unit', 'three100':'three 100',
        'full1000-class':'full 1,000-class', 'on1000classes':'on 1,000 classes',
        '1000-class':'1,000-class', 'for1000':'for 1,000', '31M/13.3M/2.1M/2.7M':'31M/13.3M/2.1M/2.7M',
        '21run':'21 run', '22unit':'22 unit', '3seeds':'3 seeds', '3one-thread':'3 one-thread',
        '3CPU':'3 CPU', '240baseline':'240 baseline', '40modified':'40 modified',
        '47updates/epoch':'47 updates/epoch', '2820updates':'2,820 updates',
        '69.8%parity':'69.8% parity', '14xheadline':'14× headline', '14x/7%update':'14× / 7% update',
        '7.82%ensemble':'7.82% ensemble', '4.82%ensemble':'4.82% ensemble',
        '144crops':'144 crops', '144-crops':'144 crops', 'normal.01':'normal std 0.01',
        'momentum.9':'momentum 0.9', 'dropout.4':'dropout 0.4', 'lr.1':'lr 0.1',
        'L2.0005':'L2 0.0005', 'L2÷5':'L2 ÷ 5', 'LR.0015':'LR 0.0015',
        'Imagenettev2':'Imagenette v2', 'single-crop25.2':'single-crop 25.2',
        'error7.82':'error 7.82', 'approximately97.23':'approximately 97.23',
        'and98.16':'and 98.16', 'about0.93':'about 0.93',
        'original74.8':'original 74.8', 'original69.8':'original 69.8',
        'source0.65':'source 0.65', 'original0.65':'original 0.65',
        'about±0.24':'about ±0.24', 'to±0.3':'to ±0.3', 'only inside':'only inside',
        'resolution1000updates':'resolution 1,000 updates', 'seed order17,29,43':'seed order 17, 29, 43',
        'baselineLR':'baseline LR', 'modelfile':'model file', '1ppwithin-shard':'1 pp within-shard',
        'sampleSD':'sample SD', 'RGB, normalization':'RGB, normalization',
        'Light/darkPNG/SVGfigures':'Light/dark PNG/SVG figures', 'underlyingCSVtable':'underlying CSV table',
        'ICML,PMLR37':'ICML, PMLR 37', 'splitseed2026':'split seed 2026',
        'selection seed2026':'selection seed 2026', 'LR multipliers1/5/30':'LR multipliers 1/5/30',
        '50passes':'50 passes', 'single deterministic crops':'single deterministic crops',
        'and7.82%':'and 7.82%', 'and4.82%':'and 4.82%', 'original13.6M':'original 13.6M',
        'canonical60,000':'canonical 60,000', 'Binary28':'Binary 28', 'Center-cropped48':'Center-cropped 48',
        'double3×3':'double 3×3', 'batch60':'batch 60', 'batch32':'batch 32', '=50 passes':'= 50 passes',
        'SGD base lr.01':'SGD base lr 0.01', 'Exponential×.1':'Exponential ×0.1',
        'per240':'per 240', 'per40':'per 40', 'Seeds17,29,43':'Seeds 17, 29, 43',
        'Dataset split:1,500':'Dataset split: 1,500', 'images,1,000':'images, 1,000',
        'has150':'has 150', 'Python3':'Python 3', 'PyTorch2':'PyTorch 2',
        'NumPy2':'NumPy 2', 'Matplotlib3':'Matplotlib 3', 'quota3':'quota 3',
        'up to3':'up to 3', 'is51.3minutes':'is 51.3 minutes',
        'fixed50k':'fixed 50k', 'over3':'over 3', 'published50k':'published 50k',
        'Reproduced50k':'Reproduced 50k', 'to50k':'to 50k', 'at≈':'at ≈',
        'using10k/50k':'using 10k/50k', 'and70%/100%ticks':'and 70%/100% ticks',
        'original31M':'original 31M', 'target72.2%':'target 72.2%', 'is47updates':'is 47 updates',
        'Same72.2%':'The same 72.2%', 'to72.2%ImageNet':'to 72.2% ImageNet',
        'seed17,29,43':'seed 17, 29, 43', 'is50%':'is 50%', 'versus0.5%':'versus 0.5%',
        'of7.82%':'of 7.82%', 'or4.82%':'or 4.82%', 'Ten-class48px':'Ten-class 48px',
        'and60-epoch':'and 60-epoch', 'Original14×':'Original 14×',
        'standard3×3stem':'standard 3×3 stem', 'separable7×7stem':'separable 7×7 stem',
        'becomes.01':'becomes 0.01', 'preserving5x/30xratios':'preserving 5×/30× ratios',
        'extra1 pp':'extra 1 pp', 'raw50k':'raw 50k', 'snapshot;22':'snapshot; 22',
        'interactiveCSVdashboard':'interactive CSV dashboard', 'optimizer,Gaussian':'optimizer, Gaussian',
        'larger1,000-class':'larger 1,000-class', 'at224px':'at 224px', 'fullImageNet':'full ImageNet',
        'absoluteLR':'absolute LR', 'validate74.8%':'validate 74.8%',
        'Ioffe,S.&Szegedy,C.(2015)':'Ioffe, S. & Szegedy, C. (2015)',
        'Szegedy(2015)':'Szegedy (2015)',
        ',7.82%':', 7.82%', ',14x':', 14×', ';(2)':'; (2) ', ';(3)':'; (3) ',
        ';(4)':'; (4) ', 'are(1)':'are (1) ', 'and(5)':'and (5) ',
        'convolutions(including':'convolutions (including',
        'brightness/contrast(.7–1.3baseline vs.9–1.1modified)':'brightness/contrast (0.7–1.3 baseline vs 0.9–1.1 modified)'
    }
    for original,replacement in typography.items():report=report.replace(original,replacement)
    (RESULTS/'fidelity_report.md').write_text(report)
    checksums={str(p.relative_to(ROOT)):digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and '.git' not in p.parts and 'data' not in p.relative_to(ROOT).parts and p.suffix in ['.py','.json','.csv','.sh','.pt','.md','.png','.svg','.pdf'] and p.name!='artifact_checksums.json'}
    (RESULTS/'artifact_checksums.json').write_text(json.dumps(checksums,indent=2))
    print('Report, tables, figures and checksums created:',RESULTS/'fidelity_report.md')
    print(json.dumps({'mnist_paired_gain_pp':mnist_delta,'proxy_dev_ranking':rank_proxy},indent=2))

if __name__=='__main__':main()
