"""Real dataset retrieval, immutable split manifests and CPU tensor caches.
No torchvision/reference dataset code. MNIST IDX parsed from documented format.
"""
import argparse
import gzip
import hashlib
import json
import struct
import tarfile
from pathlib import Path
import urllib.error
import urllib.request
import numpy as np
from PIL import Image, ImageOps
import torch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
CONFIG = ROOT / 'configs' / 'reproduction.json'

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def download(url, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        print(f'Cached {target.name}: {target.stat().st_size} bytes', flush=True)
        return
    temp = target.with_suffix(target.suffix + '.partial')
    print(f'Downloading {url}', flush=True)
    try:
        with urllib.request.urlopen(url, timeout=120) as response, open(temp, 'wb') as out:
            size = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                size += len(chunk)
        temp.replace(target)
        print(f'Downloaded {target.name}: {size} bytes sha256={digest(target)}', flush=True)
    except Exception:
        temp.unlink(missing_ok=True)
        raise

def prepare_mnist(cfg):
    directory = DATA / 'mnist'
    cache = directory / 'mnist.pt'
    if cache.exists():
        print(f'Using MNIST cache {cache}', flush=True)
        return
    names = ['train-images-idx3-ubyte.gz','train-labels-idx1-ubyte.gz',
             't10k-images-idx3-ubyte.gz','t10k-labels-idx1-ubyte.gz']
    provenance = {'dataset': 'MNIST', 'threshold': cfg['binary_threshold'], 'sources': [], 'failures': []}
    arrays = []
    for name in names:
        target = directory / name
        mirrors = ['https://storage.googleapis.com/cvdf-datasets/mnist/',
                   'https://ossci-datasets.s3.amazonaws.com/mnist/']
        for base in mirrors:
            try:
                download(base + name, target)
                provenance['sources'].append({'url': base + name, 'sha256': digest(target)})
                break
            except Exception as exc:
                print(f'MNIST mirror failure: {exc}', flush=True)
                provenance['failures'].append({'url': base + name, 'error': str(exc)})
        else:
            raise RuntimeError('Both real MNIST sources failed; no synthetic fallback allowed')
        raw = gzip.decompress(target.read_bytes())
        magic = struct.unpack('>I', raw[:4])[0]
        if magic == 2051:
            _, n, rows, cols = struct.unpack('>IIII', raw[:16])
            data = np.frombuffer(raw, dtype=np.uint8, offset=16).copy().reshape(n, rows*cols)
            arrays.append(torch.from_numpy((data / 255.0 > cfg['binary_threshold']).astype(np.float32)))
        elif magic == 2049:
            arrays.append(torch.from_numpy(np.frombuffer(raw, dtype=np.uint8, offset=8).astype(np.int64)))
        else:
            raise ValueError(f'Invalid MNIST magic {magic}')
    assert arrays[0].shape == (60000, 784) and arrays[2].shape == (10000, 784)
    torch.save(dict(zip(['train_x','train_y','test_x','test_y'],arrays)), cache)
    (directory / 'provenance.json').write_text(json.dumps(provenance, indent=2))
    print('Prepared full binary MNIST: 60000 train / 10000 test', flush=True)

def prepare_imagenette(cfg):
    directory = DATA / 'imagenette'
    directory.mkdir(parents=True, exist_ok=True)
    signature = {k: cfg[k] for k in ['image_size','train_per_class','dev_per_class','test_per_class','split_seed']}
    cache = directory / 'subset.pt'
    manifest_file = directory / 'manifest.json'
    if cache.exists() and manifest_file.exists():
        manifest = json.loads(manifest_file.read_text())
        if manifest['selection'] == signature:
            print(f'Using real Imagenette tensor cache {cache}', flush=True)
            return
        raise ValueError('Cache configuration mismatch; remove subset.pt and manifest.json explicitly')
    archive = directory / 'imagenette2-160.tgz'
    download(cfg['dataset_url'], archive)
    extracted = directory / 'imagenette2-160'
    if not extracted.exists():
        print('Extracting Imagenette archive', flush=True)
        with tarfile.open(archive, 'r:gz') as tar:
            for member in tar.getmembers():
                dest = (directory / member.name).resolve()
                if not dest.is_relative_to(directory.resolve()) or member.issym() or member.islnk():
                    raise ValueError('Unsafe archive member')
            tar.extractall(directory)
    classes = sorted(p.name for p in (extracted/'train').iterdir() if p.is_dir())
    assert len(classes) == 10
    rng = np.random.default_rng(cfg['split_seed'])
    manifest = {'dataset': 'Imagenette v2 160px', 'url': cfg['dataset_url'],
                'archive_sha256': digest(archive), 'selection': signature,
                'classes': classes, 'splits': {s: [] for s in ['train','dev','test']},
                'note': 'train/dev from disjoint official train files; test from official val, ten classes'}
    for label, cls in enumerate(classes):
        train_files = sorted(p for p in (extracted/'train'/cls).iterdir() if p.suffix.lower() in ['.jpeg','.jpg','.png'])
        val_files = sorted(p for p in (extracted/'val'/cls).iterdir() if p.suffix.lower() in ['.jpeg','.jpg','.png'])
        train_files = [train_files[i] for i in rng.permutation(len(train_files))]
        val_files = [val_files[i] for i in rng.permutation(len(val_files))]
        nt, nd, nv = cfg['train_per_class'],cfg['dev_per_class'],cfg['test_per_class']
        assert len(train_files)>=nt+nd and len(val_files)>=nv
        selections = {'train':train_files[:nt], 'dev':train_files[nt:nt+nd], 'test':val_files[:nv]}
        for split, files in selections.items():
            for p in files:
                manifest['splits'][split].append({'path':str(p.relative_to(extracted)), 'label':label, 'sha256':digest(p)})
    result = {}
    size = cfg['image_size']
    for split, entries in manifest['splits'].items():
        xs, ys = [], []
        for entry in entries:
            with Image.open(extracted / entry['path']) as img:
                img = ImageOps.fit(img.convert('RGB'), (size,size), method=Image.Resampling.BILINEAR)
                xs.append(np.asarray(img).copy().transpose(2,0,1))
                ys.append(entry['label'])
        result[split+'_x'] = torch.from_numpy(np.stack(xs))
        result[split+'_y'] = torch.tensor(ys, dtype=torch.long)
        print(f'Prepared {split}: {len(entries)} real images, {size}x{size}', flush=True)
    torch.save(result, cache)
    manifest_file.write_text(json.dumps(manifest, indent=2))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset', choices=['all','mnist','imagenette'], default='all')
    args=parser.parse_args()
    config=json.loads(CONFIG.read_text())
    if args.dataset in ['all','mnist']: prepare_mnist(config['mnist'])
    if args.dataset in ['all','imagenette']: prepare_imagenette(config['imagenette'])

if __name__=='__main__': main()
