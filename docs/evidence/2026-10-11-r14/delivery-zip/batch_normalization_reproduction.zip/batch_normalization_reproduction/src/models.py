"""Independent, CPU-friendly models for the Batch Normalization experiments.

No reference model implementations are imported. PaperBatchNorm uses PyTorch's
low-level functional primitive for its optimized CPU kernel, not nn.BatchNorm.
The explicit, differentiable equations are also exposed for numerical checks.
"""

from contextlib import contextmanager
from typing import Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as F


__all__ = [
    "paper_batch_norm_equations",
    "PaperBatchNorm",
    "MNISTMLP",
    "SmallInception",
]


def _channel_layout(x: Tensor):
    if x.ndim == 2:
        return (0,), (1, x.shape[1])
    if x.ndim == 4:
        return (0, 2, 3), (1, x.shape[1], 1, 1)
    raise ValueError("batch normalization requires a 2D (N,C) or 4D (N,C,H,W) input")


def paper_batch_norm_equations(
    x: Tensor, gamma: Tensor, beta: Tensor, eps: float = 1e-5
) -> Tensor:
    """Training-time BN equations, with gradients through both batch statistics.

    Each feature/channel is normalized over N (and H,W for convolutional data).
    The mini-batch variance has divisor m, not m-1. This pure implementation does
    not mutate running statistics; PaperBatchNorm supplies the optimized path.
    """
    dimensions, shape = _channel_layout(x)
    if gamma.shape != (x.shape[1],) or beta.shape != (x.shape[1],):
        raise ValueError("gamma and beta must be vectors matching the input channels")
    if eps <= 0:
        raise ValueError("eps must be positive")
    samples = x.shape[0] if x.ndim == 2 else x.shape[0] * x.shape[2] * x.shape[3]
    if samples <= 1:
        raise ValueError("training batch normalization needs more than one value per channel")
    mean = x.mean(dim=dimensions, keepdim=True)
    variance = x.var(dim=dimensions, unbiased=False, keepdim=True)
    normalized = (x - mean) * torch.rsqrt(variance + eps)
    return normalized * gamma.reshape(shape) + beta.reshape(shape)


class PaperBatchNorm(nn.Module):
    """Algorithm-1 batch normalization for dense and convolutional activations.

    The learned gamma/beta start at one/zero. Training uses biased batch variance
    and differentiable batch statistics. Moving variance uses the unbiased
    estimator m/(m-1) * batch_variance. Momentum is the weight of the new value:
    running_stat <- (1-momentum)*running_stat + momentum*batch_stat.

    F.batch_norm implements these same equations with an optimized CPU kernel.
    Evaluation uses only the stored running statistics and never updates them.
    """

    def __init__(self, num_features: int, eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        if not isinstance(num_features, int) or num_features <= 0:
            raise ValueError("num_features must be a positive integer")
        if eps <= 0:
            raise ValueError("eps must be positive")
        if not 0 <= momentum <= 1:
            raise ValueError("momentum must be between zero and one")
        self.num_features = num_features
        self.eps = eps
        self.momentum = momentum
        self.gamma = nn.Parameter(torch.ones(num_features))
        self.beta = nn.Parameter(torch.zeros(num_features))
        self.register_buffer("running_mean", torch.zeros(num_features))
        self.register_buffer("running_var", torch.ones(num_features))
        self.register_buffer("num_batches_tracked", torch.tensor(0, dtype=torch.long))

    @property
    def weight(self) -> nn.Parameter:
        """Conventional alias for gamma (without duplicate state-dict entries)."""
        return self.gamma

    @property
    def bias(self) -> nn.Parameter:
        """Conventional alias for beta."""
        return self.beta

    def reset_running_stats(self) -> None:
        self.running_mean.zero_()
        self.running_var.fill_(1)
        self.num_batches_tracked.zero_()

    def reset_parameters(self) -> None:
        self.reset_running_stats()
        with torch.no_grad():
            self.gamma.fill_(1)
            self.beta.zero_()

    def forward(self, x: Tensor) -> Tensor:
        _channel_layout(x)
        if x.shape[1] != self.num_features:
            raise ValueError(f"expected {self.num_features} channels, received {x.shape[1]}")
        if self.training:
            samples = x.shape[0] if x.ndim == 2 else x.shape[0] * x.shape[2] * x.shape[3]
            if samples <= 1:
                raise ValueError("training batch normalization needs more than one value per channel")
        result = F.batch_norm(
            x, self.running_mean, self.running_var, self.gamma, self.beta,
            training=self.training, momentum=self.momentum, eps=self.eps,
        )
        if self.training:
            self.num_batches_tracked.add_(1)
        return result

    def extra_repr(self) -> str:
        return f"num_features={self.num_features}, eps={self.eps}, momentum={self.momentum}"


@contextmanager
def _initialization_rng(seed: Optional[int]):
    """Optional local CPU seed, preserving the caller's RNG state when provided."""
    if seed is None:
        yield
    else:
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(seed)
            yield


def _initialize_affine_weights(model: nn.Module, conv_std: float = 0.05) -> None:
    # All configurations traverse the same affine layers in the same order.
    # BN, activation, dropout, and LRN modules consume no initialization RNG.
    for layer in model.modules():
        if isinstance(layer, (nn.Linear, nn.Conv2d)):
            nn.init.normal_(layer.weight, mean=0.0,
                            std=conv_std if isinstance(layer, nn.Conv2d) else 0.01)
            if layer.bias is not None:
                nn.init.zeros_(layer.bias)


def _linear(in_features: int, out_features: int, use_bn: bool) -> nn.Linear:
    # Always construct with bias: nn.Linear's default reset consumes random
    # numbers for biases. Removing it afterwards keeps paired RNG streams equal.
    layer = nn.Linear(in_features, out_features, bias=True)
    if use_bn:
        layer.register_parameter("bias", None)
    return layer


class MNISTMLP(nn.Module):
    """784 -> 100 -> 100 -> 100 sigmoid network, with ten output logits.

    BN, when enabled, is before each hidden sigmoid, never on the classifier.
    Hidden affine biases are redundant with beta and removed in the BN variant.
    Accepts flattened images or images with any shape flattening to 784 values.
    Reset torch.manual_seed before paired construction, or supply the same seed.
    """

    def __init__(self, use_bn: bool = False, seed: Optional[int] = None):
        super().__init__()
        self.use_bn = use_bn
        with _initialization_rng(seed):
            widths = (784, 100, 100, 100)
            self.hidden_layers = nn.ModuleList([
                _linear(widths[i], widths[i + 1], use_bn) for i in range(3)
            ])
            self.norms = nn.ModuleList([
                PaperBatchNorm(100) if use_bn else nn.Identity() for _ in range(3)
            ])
            self.classifier = nn.Linear(100, 10)
            _initialize_affine_weights(self)

    def forward(self, x: Tensor) -> Tensor:
        if x.ndim < 2:
            raise ValueError("MNISTMLP expects a batch of images or flattened images")
        x = x.flatten(start_dim=1)
        if x.shape[1] != 784:
            raise ValueError("MNISTMLP expects 784 input values per image")
        for layer, norm in zip(self.hidden_layers, self.norms):
            x = torch.sigmoid(norm(layer(x)))
        return self.classifier(x)


def _conv_activation(in_channels: int, out_channels: int, kernel_size: int,
                     use_bn: bool, activation: str, stride: int = 1) -> nn.Sequential:
    # As for dense layers, retain identical default-init RNG consumption before
    # dropping redundant biases and applying the prescribed normal initializer.
    conv = nn.Conv2d(in_channels, out_channels, kernel_size,
                     stride=stride, padding=kernel_size // 2, bias=True)
    if use_bn:
        conv.register_parameter("bias", None)
    layers = [conv]
    if use_bn:
        layers.append(PaperBatchNorm(out_channels))
    layers.append(nn.ReLU() if activation == "relu" else nn.Sigmoid())
    return nn.Sequential(*layers)


class _InceptionBlock(nn.Module):
    def __init__(self, in_channels: int, channels, use_bn: bool, activation: str):
        super().__init__()
        one, three_reduce, three, double_reduce, double, pool = channels

        def conv(input_channels, output_channels, size):
            return _conv_activation(input_channels, output_channels, size, use_bn, activation)

        self.branch1 = conv(in_channels, one, 1)
        self.branch3 = nn.Sequential(conv(in_channels, three_reduce, 1), conv(three_reduce, three, 3))
        self.branch_double3 = nn.Sequential(
            conv(in_channels, double_reduce, 1), conv(double_reduce, double, 3), conv(double, double, 3)
        )
        self.branch_pool = nn.Sequential(
            nn.AvgPool2d(3, stride=1, padding=1), conv(in_channels, pool, 1)
        )
        self.out_channels = one + three + double + pool

    def forward(self, x: Tensor) -> Tensor:
        return torch.cat((self.branch1(x), self.branch3(x),
                          self.branch_double3(x), self.branch_pool(x)), dim=1)


class SmallInception(nn.Module):
    """Small independent Inception-style proxy for ten-class Imagenette at 48px.

    This is not the full ImageNet architecture from the paper. Every convolution
    uses the chosen activation; optional BN precedes it. Defaults retain dropout
    0.4 and omit LRN. Set use_lrn=True for the optional baseline stem LRN.
    BN-Baseline can keep those regularizers; BN-x should explicitly use
    dropout=0.0 and use_lrn=False. All outputs are unnormalized classifier logits.
    """

    BLOCK_CHANNELS = (
        (8, 8, 12, 8, 12, 8),
        (12, 12, 16, 12, 16, 8),
        (16, 16, 24, 16, 24, 16),
    )

    def __init__(self, use_bn: bool = False, activation: str = "relu",
                 dropout: float = 0.4, use_lrn: bool = False,
                 seed: Optional[int] = None):
        super().__init__()
        if activation not in ("relu", "sigmoid"):
            raise ValueError("activation must be 'relu' or 'sigmoid'")
        if not 0 <= dropout <= 1:
            raise ValueError("dropout must be between zero and one")
        self.use_bn = use_bn
        self.activation = activation
        self.use_lrn = use_lrn
        with _initialization_rng(seed):
            stem = [_conv_activation(3, 16, 3, use_bn, activation, stride=2)]
            if use_lrn:
                stem.append(nn.LocalResponseNorm(5, alpha=1e-4, beta=0.75, k=2.0))
            stem.append(_conv_activation(16, 24, 3, use_bn, activation))
            if use_lrn:
                stem.append(nn.LocalResponseNorm(5, alpha=1e-4, beta=0.75, k=2.0))
            stem.append(nn.MaxPool2d(2))
            self.stem = nn.Sequential(*stem)
            blocks = []
            channels = 24
            for specification in self.BLOCK_CHANNELS:
                block = _InceptionBlock(channels, specification, use_bn, activation)
                blocks.append(block)
                channels = block.out_channels
            self.blocks = nn.ModuleList(blocks)
            self.downsample = nn.MaxPool2d(2)
            self.global_pool = nn.AdaptiveAvgPool2d(1)
            self.dropout = nn.Dropout(dropout) if dropout else nn.Identity()
            self.classifier = nn.Linear(channels, 10)
            _initialize_affine_weights(self)

    def forward(self, x: Tensor) -> Tensor:
        if x.ndim != 4 or x.shape[1] != 3:
            raise ValueError("SmallInception expects an (N,3,H,W) image batch")
        x = self.stem(x)
        for index, block in enumerate(self.blocks):
            x = block(x)
            if index < 2:
                x = self.downsample(x)
        x = self.global_pool(x).flatten(start_dim=1)
        return self.classifier(self.dropout(x))
