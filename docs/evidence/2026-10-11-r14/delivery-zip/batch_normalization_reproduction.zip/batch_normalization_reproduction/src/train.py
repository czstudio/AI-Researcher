"""Deterministic CPU-only paired experiments. No official implementations used."""
import argparse
import csv
import json
import math
import platform
import random
import time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from models import MNISTMLP, SmallInception
from data import digest

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / 'configs' / 'reproduction.json'

def fix_seed(seed, threads):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(threads)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)

def initialize(model, kind, cfg, seed):
    # Dedicated stream ensures identical affine weights despite redundant biases.
    generator = torch.Generator(device='cpu').manual_seed(seed + 10000)
    with torch.no_grad():
        for layer in model.modules():
            if isinstance(layer, (nn.Conv2d, nn.Linear)):
                if kind == 'mnist':
                    layer.weight.normal_(0, cfg['gaussian_init_std'], generator=generator)
                elif isinstance(layer, nn.Conv2d):
                    # Same initialization even for sigmoid proxy; explicitly a deviation.
                    std = math.sqrt(2 / (layer.in_channels * math.prod(layer.kernel_size)))
                    layer.weight.normal_(0, std, generator=generator)
                else:
                    layer.weight.normal_(0, .01, generator=generator)
                if layer.bias is not None: layer.bias.zero_()

def normalize(x):
    mean = x.new_tensor([.485,.456,.406]).reshape(1,3,1,1)
    std = x.new_tensor([.229,.224,.225]).reshape(1,3,1,1)
    return (x-mean)/std

def augment(x, generator, modified, cfg):
    x=x.float()/255
    mask=torch.rand(x.shape[0],generator=generator)<.5
    x[mask]=x[mask].flip(-1)
    # Pad/crop images in one vectorized gather; no Python image transforms.
    p=4
    padded=F.pad(x,(p,p,p,p),mode='reflect')
    size=x.shape[-1]
    offsets=torch.randint(0,2*p+1,(x.shape[0],2),generator=generator)
    rr=torch.arange(size)[None,:,None]+offsets[:,0,None,None]
    cc=torch.arange(size)[None,None,:]+offsets[:,1,None,None]
    x=padded[torch.arange(x.shape[0])[:,None,None],:,rr,cc].permute(0,3,1,2)
    prefix='modified' if modified else 'baseline'
    low,high=cfg[prefix+'_brightness_range']
    brightness=torch.rand((x.shape[0],1,1,1),generator=generator)*(high-low)+low
    low,high=cfg[prefix+'_contrast_range']
    contrast=torch.rand((x.shape[0],1,1,1),generator=generator)*(high-low)+low
    center=x.mean((1,2,3),keepdim=True)
    x=((x-center)*contrast+center)*brightness
    return normalize(x.clamp(0,1))

@torch.inference_mode()
def evaluate(model,x,y,image=False,batch=256):
    model.eval()
    loss,total,top1,top5=0.,0,0,0
    for start in range(0,len(y),batch):
        xx=x[start:start+batch]
        yy=y[start:start+batch]
        if image: xx=normalize(xx.float()/255)
        logits=model(xx)
        if not torch.isfinite(logits).all(): raise FloatingPointError('Nonfinite evaluation logits')
        loss+=F.cross_entropy(logits,yy,reduction='sum').item()
        top1+=(logits.argmax(1)==yy).sum().item()
        top5+=(logits.topk(5,1).indices==yy[:,None]).any(1).sum().item()
        total+=len(yy)
    return {'loss':loss/total,'top1':100*top1/total,'top5':100*top5/total,'n':total}

def write_row(writer,file,row):
    writer.writerow(row)
    file.flush()

def run_mnist(cfg,seed,out,steps_override=None):
    data=torch.load(ROOT/'data/mnist/mnist.pt',weights_only=True,map_location='cpu')
    x,y=data['train_x'],data['train_y']
    steps=steps_override or cfg['steps']
    results={}
    for name,use_bn in [('Without-BN',False),('With-BN',True)]:
        torch.manual_seed(seed)
        model=MNISTMLP(use_bn=use_bn,seed=seed).to('cpu')
        initialize(model,'mnist',cfg,seed)
        optimizer=torch.optim.SGD(model.parameters(),lr=cfg['learning_rate'],momentum=cfg['momentum'],weight_decay=cfg['weight_decay'])
        # Identical batch permutations for both models, sampling without replacement per epoch.
        sampler=torch.Generator().manual_seed(seed+1)
        order=torch.randperm(len(y),generator=sampler)
        position=0
        start=time.perf_counter()
        trace=out/f'{name}.csv'
        fields=['step','epoch','train_loss','test_loss','test_top1','test_top5','seconds']
        final=None
        with open(trace,'w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            initial=evaluate(model,data['test_x'],data['test_y'])
            write_row(writer,f,dict(step=0,epoch=0,train_loss='',test_loss=initial['loss'],test_top1=initial['top1'],test_top5=initial['top5'],seconds=time.perf_counter()-start))
            interval_loss=0.
            for step in range(1,steps+1):
                if position+cfg['batch_size']>len(y):
                    order=torch.randperm(len(y),generator=sampler);position=0
                idx=order[position:position+cfg['batch_size']];position+=cfg['batch_size']
                model.train();optimizer.zero_grad(set_to_none=True)
                loss=F.cross_entropy(model(x[idx]),y[idx])
                if not torch.isfinite(loss):raise FloatingPointError(f'{name} nonfinite loss at {step}')
                loss.backward();optimizer.step();interval_loss+=loss.item()
                if step%cfg['eval_every']==0 or step==steps:
                    final=evaluate(model,data['test_x'],data['test_y'])
                    row=dict(step=step,epoch=step*cfg['batch_size']/len(y),train_loss=interval_loss/(cfg['eval_every'] if step%cfg['eval_every']==0 else step%cfg['eval_every']),test_loss=final['loss'],test_top1=final['top1'],test_top5=final['top5'],seconds=time.perf_counter()-start)
                    write_row(writer,f,row);interval_loss=0.
                    print(f'MNIST seed={seed} {name} step={step}/{steps} test@1={final["top1"]:.2f} loss={final["loss"]:.4f} elapsed={row["seconds"]:.1f}s',flush=True)
        torch.save({'state_dict':model.state_dict(),'seed':seed,'config':cfg,'steps':steps},out/f'{name}.pt')
        results[name]={'final_test':final,'steps':steps,'seconds':time.perf_counter()-start,'parameters':sum(p.numel() for p in model.parameters()),'trace':trace.name}
    return results

def make_image_model(name,seed,cfg):
    modified=name in ['BN-x5','BN-x30','BN-x5-Sigmoid']
    model=SmallInception(use_bn=name!='Inception', activation='sigmoid' if name.endswith('Sigmoid') else 'relu',dropout=0 if modified else cfg['baseline_dropout'],use_lrn=not modified,seed=seed).to('cpu')
    initialize(model,'imagenette',cfg,seed)
    return model,modified

def run_imagenette(cfg,seed,out,epochs_override=None,only_variant=None):
    data=torch.load(ROOT/'data/imagenette/subset.pt',weights_only=True,map_location='cpu')
    epochs=epochs_override or cfg['epochs'];results={}
    names=[only_variant] if only_variant else cfg['variants']
    for name in names:
        torch.manual_seed(seed)
        model,modified=make_image_model(name,seed,cfg)
        scale=30 if name=='BN-x30' else 5 if modified else 1
        lr=cfg['base_learning_rate']*scale
        wd=cfg['base_weight_decay']*(cfg['modified_weight_decay_factor'] if modified else 1)
        # L2 only weights; no decay on BN affine or bias.
        weights=[p for p in model.parameters() if p.ndim>1]
        other=[p for p in model.parameters() if p.ndim<=1]
        optimizer=torch.optim.SGD([{'params':weights,'weight_decay':wd},{'params':other,'weight_decay':0}],lr=lr,momentum=cfg['momentum'])
        decay_epochs=cfg['base_decay_epochs']/(cfg['modified_decay_speedup'] if modified else 1)
        sampler=torch.Generator().manual_seed(seed+1)
        aug_generator=torch.Generator().manual_seed(seed+2)
        start=time.perf_counter();step=0;best=-1.;best_epoch=None;best_state=None;final=None
        trace=out/f'{name}.csv'
        fields=['epoch','step','lr','train_loss','train_top1','dev_loss','dev_top1','dev_top5','seconds']
        with open(trace,'w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            initial=evaluate(model,data['dev_x'],data['dev_y'],image=True)
            write_row(writer,f,dict(epoch=0,step=0,lr=lr,train_loss='',train_top1='',dev_loss=initial['loss'],dev_top1=initial['top1'],dev_top5=initial['top5'],seconds=time.perf_counter()-start))
            for epoch in range(1,epochs+1):
                epoch_lr=lr*cfg['decay_factor']**((epoch-1)/decay_epochs)
                for group in optimizer.param_groups:group['lr']=epoch_lr
                order=torch.randperm(len(data['train_y']),generator=sampler)
                losses=0.;correct=0;n=0
                for pos in range(0,len(order),cfg['batch_size']):
                    idx=order[pos:pos+cfg['batch_size']]
                    xx=augment(data['train_x'][idx],aug_generator,modified,cfg)
                    yy=data['train_y'][idx]
                    model.train();optimizer.zero_grad(set_to_none=True)
                    logits=model(xx);loss=F.cross_entropy(logits,yy)
                    if not torch.isfinite(loss):raise FloatingPointError(f'{name} nonfinite loss epoch {epoch} step {step}')
                    loss.backward();optimizer.step();step+=1
                    losses+=loss.item()*len(idx);correct+=(logits.argmax(1)==yy).sum().item();n+=len(idx)
                final=evaluate(model,data['dev_x'],data['dev_y'],image=True)
                if final['top1']>best:
                    best=final['top1'];best_epoch=epoch
                    best_state={k:v.detach().clone() for k,v in model.state_dict().items()}
                row=dict(epoch=epoch,step=step,lr=epoch_lr,train_loss=losses/n,train_top1=100*correct/n,dev_loss=final['loss'],dev_top1=final['top1'],dev_top5=final['top5'],seconds=time.perf_counter()-start)
                write_row(writer,f,row)
                print(f'IMAGENETTE-PROXY seed={seed} {name} epoch={epoch}/{epochs} dev@1={final["top1"]:.2f} train@1={row["train_top1"]:.2f} lr={epoch_lr:.6f} elapsed={row["seconds"]:.1f}s',flush=True)
        # Test evaluated only after development-based model selection.
        last_state={k:v.detach().clone() for k,v in model.state_dict().items()}
        last_test=evaluate(model,data['test_x'],data['test_y'],image=True)
        model.load_state_dict(best_state)
        best_test=evaluate(model,data['test_x'],data['test_y'],image=True)
        checkpoint={'state_dict':best_state,'last_state_dict':last_state,'best_epoch':best_epoch,'seed':seed,'config':cfg,'variant':name}
        torch.save(checkpoint,out/f'{name}.pt')
        results[name]={'best_dev_top1':best,'best_epoch':best_epoch,'final_dev':final,'selected_test':best_test,'last_test':last_test,'steps':step,'seconds':time.perf_counter()-start,'parameters':sum(p.numel() for p in model.parameters()),'trace':trace.name,'initial_lr':lr,'weight_decay':wd}
    return results

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset',choices=['mnist','imagenette'],required=True)
    parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--threads',type=int,default=1)
    parser.add_argument('--steps',type=int)
    parser.add_argument('--epochs',type=int)
    parser.add_argument('--variant',choices=['Inception','BN-Baseline','BN-x5','BN-x30','BN-x5-Sigmoid'])
    parser.add_argument('--output-root',type=Path,default=ROOT/'results')
    args=parser.parse_args();config=json.loads(CONFIG.read_text());cfg=config[args.dataset]
    out=args.output_root/args.dataset/f'seed_{args.seed}'
    if args.variant:out=out/args.variant
    out.mkdir(parents=True,exist_ok=True)
    fix_seed(args.seed,args.threads)
    data_files=([ROOT/'data/mnist/mnist.pt',ROOT/'data/mnist/provenance.json'] if args.dataset=='mnist' else [ROOT/'data/imagenette/subset.pt',ROOT/'data/imagenette/manifest.json'])
    data_hashes={str(p.relative_to(ROOT)):digest(p) for p in data_files}
    metadata={'python':platform.python_version(),'torch':torch.__version__,'numpy':np.__version__,'device':'cpu','threads':args.threads,'seed':args.seed,'dataset':args.dataset,'config':cfg,'data_sha256':data_hashes,'overrides':{'steps':args.steps,'epochs':args.epochs,'variant':args.variant}}
    (out/'run_config.json').write_text(json.dumps(metadata,indent=2))
    result=run_mnist(cfg,args.seed,out,args.steps) if args.dataset=='mnist' else run_imagenette(cfg,args.seed,out,args.epochs,args.variant)
    (out/'summary.json').write_text(json.dumps(result,indent=2))
    print(f'COMPLETED {args.dataset} seed {args.seed}: {out}',flush=True)

if __name__=='__main__':main()
