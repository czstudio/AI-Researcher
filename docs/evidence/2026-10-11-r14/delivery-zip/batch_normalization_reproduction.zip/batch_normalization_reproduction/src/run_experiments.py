"""Bounded CPU process orchestration with transparent, validated result reuse."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
from data import ROOT, CONFIG, digest


def fingerprint(config):
    import hashlib
    code={str(p.relative_to(ROOT)):digest(p) for p in [ROOT/'src/train.py',ROOT/'src/models.py',ROOT/'src/data.py']}
    data={str(p.relative_to(ROOT)):digest(p) for p in [ROOT/'data/mnist/mnist.pt',ROOT/'data/mnist/provenance.json',ROOT/'data/imagenette/subset.pt',ROOT/'data/imagenette/manifest.json'] if p.exists()}
    return hashlib.sha256(json.dumps({'config':config,'code':code,'data':data},sort_keys=True).encode()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--force',action='store_true',help='Retrain even if validated results exist')
    parser.add_argument('--dataset',choices=['all','mnist','imagenette'],default='all')
    args=parser.parse_args()
    config=json.loads(CONFIG.read_text())
    stamp=fingerprint(config)
    results=ROOT/'results';results.mkdir(exist_ok=True)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    def worker(dataset,seed):
        directory=results/dataset/f'seed_{seed}';directory.mkdir(parents=True,exist_ok=True)
        completion=directory/'completion.json'
        if not args.force and completion.exists() and (directory/'summary.json').exists():
            old=json.loads(completion.read_text())
            if old.get('fingerprint')==stamp:
                saved=json.loads((directory/'summary.json').read_text())
                expected={'Without-BN','With-BN'} if dataset=='mnist' else set(config['imagenette']['variants'])
                if set(saved)==expected and all((directory/v['trace']).exists() and (directory/(name+'.pt')).exists() for name,v in saved.items()):
                    print(f'REUSE complete validated {dataset} seed={seed}',flush=True)
                    return
        cmd=[sys.executable,str(ROOT/'src/train.py'),'--dataset',dataset,'--seed',str(seed),'--threads',str(config['threads_per_run'])]
        log=directory/'train.log'
        print(f'START {dataset} seed={seed}; CPU-only; log={log}',flush=True)
        with open(log,'w') as f:
            proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
        if proc.returncode:
            print(log.read_text()[-6000:],flush=True)
            raise RuntimeError(f'{dataset} seed={seed} FAILED exit={proc.returncode}, see {log}')
        completion.write_text(json.dumps({'fingerprint':stamp,'status':'completed'},indent=2))
        print(f'FINISHED {dataset} seed={seed}',flush=True)
    datasets=['mnist','imagenette'] if args.dataset=='all' else [args.dataset]
    for dataset in datasets:
        with ThreadPoolExecutor(max_workers=min(3,len(config['seeds']))) as pool:
            futures=[pool.submit(worker,dataset,seed) for seed in config['seeds']]
            for future in futures:future.result()
    print('ALL REQUESTED EXPERIMENTS COMPLETED',flush=True)

if __name__=='__main__':main()
