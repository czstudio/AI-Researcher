"""Compare every endpoint from initial and fresh full-budget executions."""
import json
from data import ROOT, CONFIG
from run_experiments import fingerprint


def main():
    initial=json.loads((ROOT/'results/initial_run_metrics.json').read_text())
    checks=[]
    for dataset,runs in initial.items():
        for seed_name,recipes in runs.items():
            current=json.loads((ROOT/'results'/dataset/seed_name/'summary.json').read_text())
            for name,old in recipes.items():
                new=current[name]
                keys=['final_test','steps','parameters'] if dataset=='mnist' else ['best_dev_top1','best_epoch','final_dev','selected_test','last_test','steps','parameters','initial_lr','weight_decay']
                for key in keys:
                    assert old[key]==new[key],f'Repeatability mismatch {dataset}/{seed_name}/{name}/{key}: {old[key]} vs {new[key]}'
                checks.append({'dataset':dataset,'seed':seed_name,'variant':name,'metric_repeatability':'EXACT','compared_summary_fields':keys})
                print(f'EXACT REPEAT {dataset} {seed_name} {name}',flush=True)
    assert len(checks)==21
    report={'status':'PASS','fingerprint':fingerprint(json.loads(CONFIG.read_text())),'runs_compared':21,'comparison':'Initial full-budget run vs fresh entrypoint --force full-budget rerun, identical runtime and fixed seeds','metric_equality':'Exact Python JSON numeric equality for all endpoint evaluation metrics/losses, selected epochs and training budgets; timings deliberately excluded','checks':checks}
    (ROOT/'results/repeatability.json').write_text(json.dumps(report,indent=2))
    print('REPEATABILITY PASS: all21run endpoints exactly repeated',flush=True)

if __name__=='__main__':main()
