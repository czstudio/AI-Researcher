# Environment notes

- Sandbox runtime Python3.11.15. `/opt/venv/bin/python3` is the existing runtime, not a new virtual environment created by this project.
- Advertised preinstalled PyTorch was absent: initial `import torch` raised `ModuleNotFoundError`.
- Initial `python3 -m pip install torch` failed because the pip module was absent.
- `python3 -m ensurepip` attempted installation into `/opt/venv/lib/python3.11/site-packages` and failed with permission denied for `distutils-precedence.pth`.
- Canonical PyPA `https://bootstrap.pypa.io/get-pip.py` succeeded with runtime `PIP_TARGET` pointing to workspace `.pypackages`; an explicit retry confirmed installation. Subsequent packages used `python3 -m pip` and the runtime redirect. No new virtual environment or unrelated custom prefix was introduced.
- CPU-only PyTorch2.5.1+cpu from `https://download.pytorch.org/whl/cpu`; NumPy2.4.6,Matplotlib3.11.1,Pillow12.3.0. Detailed resolved snapshot in `environment_freeze.txt`; PyTorch installation output in `install.log`. Early failure text is summarized here because that log was replaced by the successful installation log.
- CPU physical/affinity count8, but container `cpu.max`=300000/100000 gives a3-core quota. `memory.max`=8589934592 (8GiB).
- Training orchestration runs at most three processes simultaneously, each with PyTorch intra-op/inter-op and BLAS thread counts1. CUDA is hidden and all models/tensors are explicitly CPU.
- Optional source-curve extraction used pre-existing PyMuPDF/fitz and `pdftotext`; ordinary reproduction uses the included vector references, so these are not runtime training dependencies.
- Node18 treated the dataviz validator `.js` as CommonJS; copying the supplied ES-module script to `.mjs` and importing its exported validator resolved the issue. Both selected figure palettes passed all gates. No colorblind-safety assumption was substituted for validation.
- Actual experiments are deterministic under the identical recorded runtime. Cross-hardware/library-version bitwise equality is not promised. Timings are not reproducibility metrics.
