# Independent reproduction audit

Read-only review performed after the initial implementation, while ImageNet-proxy training was active. No configuration or numerical result was altered by the reviewer.

Verified: CPU-only; independent implementation/no reference model imports; correct BN forward/backward, biased train and unbiased moving variance; nonoverlapping real train/dev/test; identical paired affine initialization and sampler permutations; correct LR1/5/30 and sixfold modified decay; transparent proxy-vs-original metric noncomparability; source naming correction defensible; MNIST interpolation points inside observed source curve domains.22tests passed.

Findings and fixes:
1. Original result-reuse fingerprint omitted dataset caches/provenance. Fixed by incorporating cache/manifest SHA256s and recording actual data hashes in each new run_config.json. Full entrypoint retraining required after this fix, rather than relabelling old runs as newly provenance-bound. Checkpoint audit verifies data hashes.
2. “Test once” could imply a single evaluation; in fact selected and final checkpoints are both tested after training/dev selection and retested for verification. Wording clarified. This was not train/test leakage: test metrics are never used in selection.
3. No out-of-bounds source interpolation occurred, but explicit bounds/monotonicity assertions were added because NumPy otherwise clamps outside the domain.

Reviewer confirmed MNIST initial-run paired gain:0.287±0.104percentage points. No promise of exact ImageNet numerical parity or full-dataset acceleration was found. Final measured ImageNet-proxy ranking must be reported even if it differs from the source.
