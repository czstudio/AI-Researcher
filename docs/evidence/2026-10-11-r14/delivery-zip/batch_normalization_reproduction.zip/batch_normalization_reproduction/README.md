# Batch Normalization: independent CPU reproduction

Source: Ioffe & Szegedy (2015), [arXiv:1502.03167](https://arxiv.org/abs/1502.03167).

**Start here:** [`results/fidelity_report.md`](results/fidelity_report.md) for published-value comparisons, measured results and limitations. [`REPRODUCTION_PLAN.md`](REPRODUCTION_PLAN.md) defines scope, source-to-code mapping and predeclared assumptions.

## What this actually reproduces

- **MNIST Figure 1a:** full real 60,000/10,000 dataset; paper's **three 100-unit sigmoid MLP**, not convolutional LeNet; 50,000 updates, batch 60, baseline vs BN, three seeds.
- **ImageNet classification column:** interpreted as the maximum-accuracy column in the source's **Figure 3**, because neither retrieved version labels Table 1 column B. All five recipes are trained independently on a **real Imagenette proxy**: 1,500 train / 500 development / 1,000 test images, 10 classes, 48px, three-block Inception network, 60 epochs, three seeds.
- **Not reproduced:** full ImageNet absolute accuracies, original full architecture/distributed schedule, 14× full-ImageNet speedup, ensemble/multicrop/server error.

No official implementation imports, no pretrained weights, no synthetic data, no GPU use. PyTorch functional operators are used normally; independent BN equations are included and checked against the optimized kernel.

## Run

```bash
bash /home/novix/workspace/project/entrypoint.sh
# Force every experiment to train from scratch:
bash /home/novix/workspace/project/entrypoint.sh --force
```

Entrypoint works from any current directory. Uses existing Python environment, installs CPU-only torch and pinned plotting/data dependencies if needed, downloads real data (~110MB compressed), performs 22 tests, executes experiments, verifies all 21 checkpoint/metric/budget pairs and creates the report and figures. Source PDFs and vector-digitized MNIST reference data are included. No virtual environment is created.

Default behavior reuses **complete, fingerprint-matching** runs with a visible `REUSE` log message. Missing/mismatching training-code/config/dataset-cache/provenance fingerprints cause full retraining. Every run records hashes of the actual training-data cache and source/split manifest; verification checks those hashes again. `--force` always retrains. Expect roughly 25–35 minutes fresh execution on a 3-core CPU quota; cached verification is much faster. Runtime varies. Data + installed dependencies + caches require disk space; memory limit of 8GiB is sufficient. Three single-thread runs proceed concurrently.

## Project layout

```text
configs/reproduction.json        Locked seeds and experimental hyperparameters
src/models.py                   Independent BN, paper sigmoid MLP, small Inception
src/data.py                     MNIST IDX reader, Imagenette download/split/provenance
src/train.py                    CPU-only deterministic training/evaluation
src/run_experiments.py          Bounded orchestration and transparent result reuse
src/digitize_paper.py            Optional original PDF vector-curve extraction
src/validate_results.py          Complete-budget and checkpoint metric audit
src/analyze.py                   Comparative tables, figures and fidelity report
sources/                        Paper PDFs/text, published values and MNIST vectors
tests/                          22 numerical and pipeline tests
data/                           Downloaded data, immutable manifests and tensor caches
results/                        Raw traces/logs/configs/checkpoints, summary/report/figures
entrypoint.sh                   Complete reproducible workflow
```

The MNIST graph extraction helper requires PyMuPDF only when re-extracting the source vector data; ordinary entrypoint analysis reads the included reference JSON/CSV and does not require PyMuPDF, PDF utilities or web search.

## Results protocol

Accuracy values are percentages. Report mean ± **sample standard deviation**, not confidence intervals, over seeds 17, 29 and 43. Same initial affine weights and data permutations are used in paired comparisons. MNIST primary endpoint is **fixed final-step test accuracy**. Proxy model selection uses the development split only; report maximum development accuracy, selected-checkpoint held-out test and final-checkpoint test separately. The split is fixed and hash-manifested. Proxy numerical gaps against the paper are **not same-benchmark differences**.

CSV tables are also the accessible table views for static figures. Light and dark PNG/SVG exports have deliberately selected, validated palettes. BN entities also use line-style encoding. Raw source vector paths allow plotted-reference uncertainty to be audited; paper graph endpoints are not invented exact published metrics.

No hidden tuning or failed-run deletion. Any original claim unsupported by the reduced setup is explicitly marked unverified in the fidelity report.
