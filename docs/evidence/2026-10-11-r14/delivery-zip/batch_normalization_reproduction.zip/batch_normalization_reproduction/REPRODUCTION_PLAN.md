# Source-anchored reproduction plan

## Primary sources and naming corrections
- Ioffe & Szegedy, arXiv:1502.03167: https://arxiv.org/abs/1502.03167 ; local `sources/paper.pdf` and extracted `paper.txt`.
- Published ICML paper: https://proceedings.mlr.press/v37/ioffe15.pdf ; local `sources/icml_paper.pdf`.
- The requested Figure 1 left is a **sigmoid MLP**, not a convolutional LeNet: 784→100→100→100→10. The experiment description is section 4.1.
- Neither retrieved version contains a table labelled Table 1 with a column labelled B. Interpret the requested classification column as the **maximum accuracy column in Figure 3**, the single-network summary supporting section 4.2.2. Include all five rows. Figure 4 supplies optional single-crop top-1/top-5 error references. This interpretation is explicit, not an invented table reference.

## Core contributions, ordered by impact on this request
1. Differentiable, per-feature mini-batch normalization followed by learned scale/shift; population statistics for deterministic inference (Algorithms 1/2, sections 3/3.1).
2. Insert BN before nonlinearities; normalize each convolution channel over batch AND spatial locations (section 3.2).
3. Faster optimization and higher accuracy: full MNIST sigmoid network comparison (Figure 1a).
4. Single-crop ImageNet accuracy and learning acceleration, especially BN-Baseline vs baseline, then BN-x5/x30 (Figures 2/3).
5. Practical BN-enabled changes: higher LR, no dropout/LRN, reduced L2, faster exponential decay and reduced photometric distortion; sigmoid viability.
The paper's internal-covariate-shift explanation is a hypothesis; accuracy alone cannot establish that causal mechanism.

## In-scope
- Independently authored PyTorch code, CPU-only, from-scratch weights, no official model/training repository imports, real data.
- Full MNIST train/test (60k/10k), 50k updates, batch 60, three 100-unit sigmoid hidden layers; three paired seeds; test accuracy traces at 1k updates.
- Real Imagenette v2 (ten ILSVRC2012 synsets), deterministic 1500 train / 500 development / 1000 held-out test subset. Development and train are disjoint official training images. Test comes from official validation images.
- Three-inception-block, 48px **proxy** comparison for all five single-network variants, 60 full epochs per variant, batch32, three seeds. Test only after checkpoint selection on development split.
- Numeric BN forward/backward/run-stat/gradcheck tests, fixed configs, logs, checkpoints, CSV traces, comparison figures, fidelity report, end-to-end entrypoint.

## Out-of-scope
- Full 1.28M-image, 1000-class ImageNet, original 13.6M-parameter ten-module 224px Inception, distributed asynchronous SGD and tens of millions of updates.
- Six-network ensemble, 144-crop inference, ILSVRC test-server submission / 4.82% top-5 claim.
- MNIST activation-distribution panels Figure 1b/c; architecture appendix replication beyond its double-3x3 design principle.
- Proving the internal-covariate-shift causal explanation, tuning to published test numbers.

## Published numeric references
Figure 3 maximum single-crop top-1 accuracy (%): Inception72.2; BN-Baseline72.7; BN-x5 73.0; BN-x30 74.8; BN-x5-Sigmoid69.8.
Steps to72.2%:31.0M,13.3M,2.1M,2.7M,not reached, respectively. Ratios31/13.3≈2.33;31/2.1≈14.76;31/2.7≈11.48. Paper prose calls x5 speedup14x.
Figure4 BN-Inception single crop top-1 error25.2%, top-5 error7.82%.
Figure1a has no exact endpoint table: source graph endpoints will be explicitly digitized with pixel uncertainty, never treated as exact tabulated values.

## Method-to-code traceability
| Paper component | Code | Configuration | Execution/output |
|---|---|---|---|
| Algorithm1 biased batch variance and gamma/beta | `src/models.py:paper_batch_norm_equations`, `PaperBatchNorm` | epsilon1e-5, momentum(new)=0.1 | `tests/test_models.py`, `results/tests.log` |
| Algorithm2 unbiased population variance and eval | `PaperBatchNorm.forward` optimized `F.batch_norm` | same | eval-batch invariance tests; checkpoints |
| §4.1 sigmoid MLP | `MNISTMLP`, `src/train.py:run_mnist` | `configs/reproduction.json:mnist` | `src/train.py --dataset mnist --seed N`; CSV/summary/checkpoints |
| §3.2 convolution-channel BN | `SmallInception`, `_conv_activation` | `imagenette` | BN numerical 4D tests |
| §4.2 double3x3 branch | `_InceptionBlock` | documented three-block channel specs in model | all Imagenette proxy runs |
| §4.2.1 BN-enabled recipe | `make_image_model`, `run_imagenette`, `augment` | LR multipliers1/5/30, dropout.4/0,L2factor.2,decay6x | five variant CSVs and selected-test results |
| §4.2.2 single-crop @1 | `evaluate`, `src/analyze.py` | 48px center crops, dev selection | comparison.csv, fidelity_report.md, figures |
| Real data provenance | `src/data.py` | subset sizes, splitseed2026 | MNIST provenance, Imagenette manifest with hashes |

## Missing paper details bridged by assumptions (locked before final runs)
- MNIST learning rate, optimizer/momentum, Gaussian std, numerical epsilon and moving-average coefficient are unspecified: choose SGD lr.1 momentum.9, std.1, eps1e-5, newstatweight.1. Std.1 is a small zero-mean Gaussian, not a claimed published value.
- Paper says binary MNIST but no threshold specified: binarize >.5 of raw/255, no other normalization.
- MNIST use canonical60000/10000 split; shuffled without replacement per epoch; compare identical initial affine weights and batch permutations.
- Imagenette drastically reduces task complexity and changes class count/resolution/data volume; absolute gaps to ImageNet are descriptive only.
- Small proxy uses three modules instead of ten, standard 3x3 stem instead of original 7x7 depth-multiplier8 separable stem, explicit maxpool between modules, no auxiliary heads. Full architecture diagram not reproduced.
- Proxy uses Kaiming normal conv initialization even in sigmoid variant, normal.01 classifier; original initialization details unspecified. BN same affine initialization as baseline.
- Original ImageNet base LR.0015 vs chosen proxy.01; ratios5x/30x preserved. Momentum.9 and L2.0005 assumed. One-tenth decay over240 baseline epochs vs40 modified epochs (sixfold acceleration); original decay constant unavailable.
- Same full shuffle for all variants rather than intentionally weak baseline shuffle; isolates other recipe effects and cannot reproduce paper's claimed1pp shuffle gain.
- Proxy randomly reflects/crops cached48px images, plus brightness/contrast ranges; modified range narrower. Not original 224px augmentation.
- 60 epochs is a complete predeclared proxy training budget, not claimed convergence of original distributed ImageNet schedule.
- Optimized PyTorch `functional.batch_norm` used for training throughput, with independent autograd equation implementation and numerical tests; allowed PyTorch primitive, no reference model imports.

## Evaluation decision rules
- MNIST primary endpoint is fixed final-step test accuracy (mean±sample SD over3 seeds); traces and steps to90/95% provide optimization-trend checks without choosing test-optimal checkpoint.
- Proxy primary analog of published maximum validation accuracy is maximum development accuracy; additionally report held-out test accuracy of dev-selected model and fixed-final-epoch test accuracy.
- Derive proxy updates-to-own-baseline-best development accuracy; do not mistake reaching72.2% on ten classes for ImageNet72.2%.
- Every gap to original ImageNet is labelled non-comparable. If a BN recipe underperforms or ranking differs, retain it and report trend not reproduced; never discard inconvenient runs.
- All training is CPU float32. Hardware quota3 CPU cores, memory8GiB; three one-thread runs concurrently.
